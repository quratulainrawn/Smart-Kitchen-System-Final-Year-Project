import 'package:flutter/material.dart';
import 'package:meals_config_fire/models/smart_kitchen.dart';

class NotificationBadge extends StatelessWidget {
  final SmartKitchen kitchenData;
  final VoidCallback? onTap;
  
  const NotificationBadge({
    super.key,
    required this.kitchenData,
    this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    // Calculate the number of active alerts
    int notificationCount = 0;
    
    if (kitchenData.babyCry) notificationCount++;
    if (kitchenData.gasLevel > 3200) notificationCount++;
    if (kitchenData.temperature > 40.0) notificationCount++;

    return GestureDetector(
      onTap: onTap,
      child: Stack(
        clipBehavior: Clip.none,
        children: [
          IconButton(
            icon: Icon(
              Icons.notifications,
              color: notificationCount > 0 
                  ? Theme.of(context).colorScheme.primary
                  : Theme.of(context).iconTheme.color,
            ),
            onPressed: onTap,
          ),
          if (notificationCount > 0)
            Positioned(
              right: 4,
              top: 4,
              child: Container(
                padding: const EdgeInsets.all(2),
                decoration: BoxDecoration(
                  color: Colors.red,
                  borderRadius: BorderRadius.circular(10),
                ),
                constraints: const BoxConstraints(
                  minWidth: 18,
                  minHeight: 18,
                ),
                child: Text(
                  notificationCount > 9 ? '9+' : '$notificationCount',
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 10,
                    fontWeight: FontWeight.bold,
                  ),
                  textAlign: TextAlign.center,
                ),
              ),
            ),
        ],
      ),
    );
  }
}