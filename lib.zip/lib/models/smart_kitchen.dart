// class SmartKitchen {
//   bool babyCry;
//   bool fanStatus;
//   int gasLevel;
//   int humidity;
//   Notifications notifications;
//   int soundDetected;
//   int soundLevel;
//   double temperature;

//   SmartKitchen({
//     required this.babyCry,
//     required this.fanStatus,
//     required this.gasLevel,
//     required this.humidity,
//     required this.notifications,
//     required this.soundDetected,
//     required this.soundLevel,
//     required this.temperature,
//   });

  
//   factory SmartKitchen.fromJson(Map<dynamic, dynamic> json) {
//     return SmartKitchen(
//       babyCry: json['babyCry'] ?? false,
//       fanStatus: json['fanStatus'] ?? false,
//       gasLevel: json['gasLevel'] ?? 0,
//       humidity: json['humidity'] ?? 0,
//       notifications: Notifications.fromJson(
//         json['notifications'] is Map 
//           ? Map<String, dynamic>.from(json['notifications']) 
//           : {},
//       ),
//       soundDetected: json['soundDetected'] ?? 0,
//       soundLevel: json['soundLevel'] ?? 0,
//       temperature: (json['temperature'] ?? 0).toDouble(),
//     );
//   }
// }

// class Notifications {
//   String babyCry;
//   String gas;
//   String temperature;

//   Notifications({
//     required this.babyCry,
//     required this.gas,
//     required this.temperature,
//   });

//   factory Notifications.fromJson(Map<String, dynamic> json) {
//     return Notifications(
//       babyCry: json['babyCry']?.toString() ?? '',
//       gas: json['gas']?.toString() ?? '',
//       temperature: json['temperature']?.toString() ?? '',
//     );
//   }

  
// }

class SmartKitchen {
  bool babyCry;
  bool fanStatus;
  int gasLevel;
  double humidity; // <-- changed from int to double
  Notifications notifications;
  int soundDetected;
  int soundLevel;
  double temperature;

  SmartKitchen({
    required this.babyCry,
    required this.fanStatus,
    required this.gasLevel,
    required this.humidity,
    required this.notifications,
    required this.soundDetected,
    required this.soundLevel,
    required this.temperature,
  });

  factory SmartKitchen.fromJson(Map<dynamic, dynamic> json) {
    double parseDouble(dynamic value) {
      if (value is int) return value.toDouble();
      if (value is double) return value;
      return 0.0;
    }

    return SmartKitchen(
      babyCry: json['babyCry'] ?? false,
      fanStatus: json['fanStatus'] ?? false,
      gasLevel: json['gasLevel'] ?? 0,
      humidity: parseDouble(json['humidity']), // <-- handle int/double
      notifications: Notifications.fromJson(
        json['notifications'] is Map
          ? Map<String, dynamic>.from(json['notifications'])
          : {},
      ),
      soundDetected: json['soundDetected'] ?? 0,
      soundLevel: json['soundLevel'] ?? 0,
      temperature: parseDouble(json['temperature']), // <-- handle int/double
    );
  }
}

class Notifications {
  String babyCry;
  String gas;
  String temperature;

  Notifications({
    required this.babyCry,
    required this.gas,
    required this.temperature,
  });

  factory Notifications.fromJson(Map<String, dynamic> json) {
    return Notifications(
      babyCry: json['babyCry']?.toString() ?? '',
      gas: json['gas']?.toString() ?? '',
      temperature: json['temperature']?.toString() ?? '',
    );
  }
}
