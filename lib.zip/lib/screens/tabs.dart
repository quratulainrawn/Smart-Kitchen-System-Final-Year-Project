import 'package:flutter/material.dart';
import 'package:meals_config_fire/data/dummy_data.dart';
import 'package:meals_config_fire/screens/categories.dart';
import 'package:meals_config_fire/screens/chat_screen.dart';
import 'package:meals_config_fire/screens/meals.dart';
import 'package:meals_config_fire/models/meal.dart';
import 'package:meals_config_fire/widgets/drawer.dart';
import 'package:meals_config_fire/screens/filters.dart';
import 'package:meals_config_fire/models/message.dart';
import 'package:meals_config_fire/screens/home_screen.dart';

const kinitialFilters = {
  Filter.glutenFree: false,
  Filter.lactoseFree: false,
  Filter.vegetarian: false,
  Filter.vegan: false,
};

List<Message> _chatMessages = [];

class Tabs extends StatefulWidget {
  const Tabs({super.key});
  @override
  State<Tabs> createState() {
    return _TabsState();
  }
}

class _TabsState extends State<Tabs> {
  int _selectedPageIndex = 0;
  final List<Meal> _favoriteMeals = [];
  Map<Filter, bool> _sellectedFilters = kinitialFilters;

  void _showInforMsg(String message) {
    ScaffoldMessenger.of(context).clearSnackBars();
    ScaffoldMessenger.of(
      context,
    ).showSnackBar(SnackBar(content: Text(message)));
  }

  void _onSelectScreen(String identifier) async {
    Navigator.of(context).pop();
    if (identifier == 'filters') {
      final result = await Navigator.of(context).push<Map<Filter, bool>>(
        MaterialPageRoute(
          builder: (ctx) => Filters(currentFilters: _sellectedFilters),
        ),
      );

      setState(() {
        _sellectedFilters = result ?? kinitialFilters;
      });
    }
    if (identifier == 'assistant') {
      final result = await Navigator.of(context).push<List<Message>>(
        MaterialPageRoute(
          builder: (ctx) => ChatScreen(previousMessages: _chatMessages),
        ),
      );

      setState(() {
        _chatMessages = result ?? _chatMessages;
      });
    }
    if (identifier == 'monitoring') {
      Navigator.of(
        context,
      ).push(MaterialPageRoute(builder: (ctx) => HomeScreen()));
    }
  }

  void _toggleMealFavoriteStatus(Meal meal) {
    final _isExisting = _favoriteMeals.contains(meal);
    setState(() {
      if (_isExisting) {
        _favoriteMeals.remove(meal);
        _showInforMsg('Meal is no longer a favorite');
      } else {
        _favoriteMeals.add(meal);
        _showInforMsg('Marked as Favorite');
      }
    });
  }

  void _onSelectPage(int index) {
    setState(() {
      _selectedPageIndex = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    final _availableMeals =
        dummyMeals.where((meal) {
          if (_sellectedFilters[Filter.glutenFree]! && !meal.isGlutenFree) {
            return false;
          }
          if (_sellectedFilters[Filter.lactoseFree]! && !meal.isLactoseFree) {
            return false;
          }
          if (_sellectedFilters[Filter.vegetarian]! && !meal.isVegetarian) {
            return false;
          }
          if (_sellectedFilters[Filter.vegan]! && !meal.isVegan) {
            return false;
          }
          return true;
        }).toList();

    Widget _activePage = CategoriesScreen(
      onToggleFavorite: _toggleMealFavoriteStatus,
      availableMeals: _availableMeals,
    );
    var _activePageTitle = 'Categories';

    if (_selectedPageIndex == 1) {
      _activePage = Meals(
        meals: _favoriteMeals,
        onToggleFavorite: _toggleMealFavoriteStatus,
      );
      _activePageTitle = 'Favorites';
    }

    return Scaffold(
      drawer: MainDrawer(onSelectScreen: _onSelectScreen),
      appBar: AppBar(title: Text(_activePageTitle)),
      body: _activePage,
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _selectedPageIndex,
        onTap: (index) {
          _onSelectPage(index);
        },
        items: [
          BottomNavigationBarItem(
            icon: Icon(Icons.set_meal),
            label: 'Categories',
          ),
          BottomNavigationBarItem(icon: Icon(Icons.star), label: 'Favorites'),
        ],
      ),
    );
  }
}
