import 'dart:async';
import 'package:flutter/material.dart';
import 'package:firebase_database/firebase_database.dart';
import 'package:meals_config_fire/models/smart_kitchen.dart';
import 'package:meals_config_fire/services/alert_manager.dart';

import '../utils/firebase_helpers.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  SmartKitchen? _kitchenData;
  StreamSubscription<DatabaseEvent>? _databaseSubscription;
  bool _isLoading = true;
  String? _errorMessage;

  @override
  void initState() {
    super.initState();
    _setupRealTimeListener();
  }

  // ... (keep existing state variables)

  void _setupRealTimeListener() {
    final ref = FirebaseDatabase.instance.ref('SmartKitchen');

    _databaseSubscription = ref.onValue.listen(
      (DatabaseEvent event) {
        if (!mounted) return;

        setState(() => _isLoading = false);

        if (event.snapshot.exists) {
          try {
            final dynamic rawData = event.snapshot.value;
            final convertedData = convertFirebaseData(rawData);

            if (convertedData is Map<String, dynamic>) {
              final currentData = SmartKitchen.fromJson(convertedData);

              setState(() {
                _kitchenData = currentData;
                _errorMessage = null;
              });

              AlertManager().handleCriticalAlerts(currentData);
            } else {
              setState(() => _errorMessage = 'Data format is invalid');
            }
          } catch (e) {
            setState(() => _errorMessage = 'Failed to process data');
            debugPrint(
              'Data processing error: $e\nData: ${event.snapshot.value}',
            );
          }
        } else {
          setState(() => _errorMessage = 'No data available at path');
        }
      },
      onError: (error) {
        if (!mounted) return;
        setState(() {
          _isLoading = false;
          _errorMessage = 'Connection error: ${error.message}';
        });
      },
    );
  }

  // void _setupRealTimeListener() {
  //   final ref = FirebaseDatabase.instance.ref('SmartKitchen');

  //   _databaseSubscription = ref.onValue.listen((DatabaseEvent event) {
  //     if (!mounted) return;

  //     setState(() => _isLoading = false);

  //     if (event.snapshot.exists) {
  //       try {
  //         final data = event.snapshot.value as Map<dynamic, dynamic>;
  //         final currentData = SmartKitchen.fromJson(Map<String, dynamic>.from(data));

  //         setState(() {
  //           _kitchenData = currentData;
  //           _errorMessage = null;
  //         });

  //         AlertManager().handleAlerts(currentData);
  //       } catch (e) {
  //         setState(() => _errorMessage = 'Failed to parse data: $e');
  //         debugPrint('Error parsing data: $e');
  //       }
  //     } else {
  //       setState(() => _errorMessage = 'No data available');
  //     }
  //   }, onError: (error) {
  //     if (!mounted) return;
  //     setState(() {
  //       _isLoading = false;
  //       _errorMessage = 'Database error: ${error.message}';
  //     });
  //   });
  // }

  @override
  void dispose() {
    _databaseSubscription?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Kitchen Monitor'), centerTitle: false),
      body: _buildBody(),
      floatingActionButton: FloatingActionButton(
        onPressed: _refreshData,
        child: const Icon(Icons.refresh),
      ),
    );
  }

  Widget _buildBody() {
    if (_isLoading) {
      return const Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            CircularProgressIndicator(),
            SizedBox(height: 16),
            Text(
              'Connecting to Smart Kitchen...',
              style: TextStyle(color: Color.fromARGB(255, 194, 152, 120)),
            ),
          ],
        ),
      );
    }

    if (_errorMessage != null) {
      return Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.error_outline, size: 48, color: Colors.red),
            const SizedBox(height: 16),
            Text(
              _errorMessage!,
              textAlign: TextAlign.center,
              style: const TextStyle(color: Colors.red),
            ),
            const SizedBox(height: 16),
            ElevatedButton(onPressed: _refreshData, child: const Text('Retry')),
          ],
        ),
      );
    }

    if (_kitchenData == null) {
      return const Center(child: Text('No data received'));
    }

    return ListView(
      padding: const EdgeInsets.all(16),
      children: [
        _buildStatusCard(
          'Temperature',
          '${_kitchenData!.temperature}°C',
          Icons.thermostat,
          _kitchenData!.temperature > 40 ? Colors.orange : Colors.green,
        ),
        _buildStatusCard(
          'Gas Level',
          _kitchenData!.gasLevel.toString(),
          Icons.gas_meter,
          _kitchenData!.gasLevel > 3200 ? Colors.red : Colors.green,
        ),
        _buildStatusCard(
          'Baby Status',
          _kitchenData!.babyCry ? 'Crying' : 'Calm',
          Icons.child_care,
          _kitchenData!.babyCry ? Colors.blue : Colors.green,
        ),
        _buildStatusCard(
          'Humidity',
          '${_kitchenData!.humidity?.toStringAsFixed(1) ?? 'N/A'}%',
          Icons.water_drop,
          _kitchenData!.humidity > 70 ? Colors.blue : Colors.green,
        ),
      ],
    );
  }

  Widget _buildStatusCard(
    String title,
    String value,
    IconData icon,
    Color color,
  ) {
    return Card(
        child: ListTile(
          leading: Icon(icon, color: color),
          title: Text(title),
          trailing: Text(value, style: TextStyle(color: color)),
        ),
      );
    
  }

  Future<void> _refreshData() async {
    if (!mounted) return;
    setState(() {
      _isLoading = true;
      _errorMessage = null;
    });
    _databaseSubscription?.cancel();
    _setupRealTimeListener();
  }
}
