import 'package:flutter/material.dart';
import '../services/chat_service.dart';
import 'package:material_design_icons_flutter/material_design_icons_flutter.dart';
import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:meals_config_fire/models/message.dart';
// 👈 Your model file

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key, required this.previousMessages});
  final List<Message> previousMessages;

  @override
  _ChatScreenState createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  late List<Message> _messages;
  bool _isTyping = false;
  final TextEditingController _controller = TextEditingController();
  //List<Message> _chatMessages = [];

  Future<void> saveMessages(List<Message> messages) async {
    final prefs = await SharedPreferences.getInstance();
    final messageListJson = messages.map((msg) => msg.toJson()).toList();
    prefs.setString('chat_history', jsonEncode(messageListJson));
  }

  Future<List<Message>> loadMessages() async {
    final prefs = await SharedPreferences.getInstance();
    final jsonString = prefs.getString('chat_history');
    if (jsonString != null) {
      final decoded = jsonDecode(jsonString) as List;
      return decoded.map((msg) => Message.fromJson(msg)).toList();
    }
    return [];
  }

  // @override
  // void initState() {
  //   super.initState();
  //   loadMessages().then((loadedMessages) {
  //     setState(() {
  //       _chatMessages = loadedMessages;
  //     });
  //   });
  // }

 @override
  void initState() {
    super.initState();
    _messages = List.from(widget.previousMessages);
  }

  

//   void _sendMessage() async {
//   final text = _controller.text.trim();
//   if (text.isEmpty) return;

//   _addMessage(text, true); // 👈 save and show user message
//   _controller.clear();
//   setState(() => _isTyping = true
    
//   );

//   try {
//     final response = await ChatService.sendMessage(text);
//     _addMessage(response, false); // 👈 save and show bot response
//   } catch (e) {
//     ScaffoldMessenger.of(context).showSnackBar(
//       SnackBar(content: Text("Error: ${e.toString()}")),
//     );
//   } finally {
//     setState(() => _isTyping = false);
//   }
// }
void _sendMessage() async {
  final text = _controller.text.trim();
  if (text.isEmpty) return;

  setState(() {
    _addMessage(text, true);  // Add user message
    _isTyping = true;
  });

  _controller.clear();

  try {
    final response = await ChatService.sendMessage(text);
    setState(() {
      _addMessage(response, false);  // Add bot response
    });
  } catch (e) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Error: ${e.toString()}")),
    );
  } finally {
    setState(() {
      _isTyping = false;
    });
  }
}



  void _addMessage(String text, bool isUser) {
    final newMessage = Message(
      text: text,
      isUser: isUser,
      timestamp: DateTime.now(),
    );
    setState(() {
      _messages.add(newMessage);
    });
    saveMessages(_messages); // 💾 persist
  }

  @override
  Widget build(BuildContext context) {
    return WillPopScope(
      onWillPop: () async {
      Navigator.of(context).pop(_messages);  // send updated chat back
      return false;
    },
      child: Scaffold(
        backgroundColor: const Color(0xFFF5F5F5),
        appBar: AppBar(
          title: const Text("Meal Assistant"),
          backgroundColor: const Color(0xFF003049),
          foregroundColor: Colors.white,
        ),
        body: Column(
          children: [
            Expanded(
              child: ListView.builder(
                itemCount:
                    _messages.length +
                    (_isTyping ? 1 : 0), // 👈 Add extra item if typing
                itemBuilder: (context, index) {
                  if (_isTyping && index == _messages.length) {
                    return const ChatBubble(
                      text: "Bot is thinking...",
                      isUser: false,
                      isTyping: true,
      
                      // 👈 we'll handle animation
                    );
                  }
      
                  final message = _messages[index];
                  return ChatBubble(
                    text: message.text,
                    isUser: message.isUser,
                    timestamp: message.timestamp,
                    isTyping:
                        _isTyping &&
                        index ==
                            _messages.length, // 👈 ONLY show typing on latest
                  );
                },
              ),
            ),
      
            const Divider(height: 2),
            Padding(
              padding: EdgeInsets.only(bottom: 16),
              child: Container(
                padding: const EdgeInsets.all(8),
                color: Colors.white,
                child: Row(
                  children: [
                    Expanded(
                      child: SizedBox(
                        height: 48,
                        child: TextField(
                          maxLines: null, // 👈 allows multiple lines
                          minLines: 1,
                          keyboardType: TextInputType.multiline,
                          controller: _controller,
                          decoration: InputDecoration(
                            hintText: "Ask about meals...",
                            filled: true,
                            fillColor: Colors.grey[100],
                            border: OutlineInputBorder(
                              borderRadius: BorderRadius.circular(12),
                              borderSide: BorderSide.none,
                            ),
                            contentPadding: const EdgeInsets.symmetric(
                              horizontal: 16,
                            ),
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 8),
                    CircleAvatar(
                      backgroundColor: const Color(0xFF003049),
                      child: IconButton(
                        icon: const Icon(Icons.send, color: Colors.white),
                        onPressed: _sendMessage,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

class ChatBubble extends StatelessWidget {
  final String text;
  final bool isUser;
  final bool isTyping;
  final DateTime? timestamp;

  const ChatBubble({
    super.key,
    required this.text,
    required this.isUser,
    this.isTyping = false,
    this.timestamp,
  });

  String _formatTimestamp(DateTime timestamp) {
    final time = TimeOfDay.fromDateTime(timestamp);
    final hour = time.hourOfPeriod == 0 ? 12 : time.hourOfPeriod;
    final period = time.period == DayPeriod.am ? 'AM' : 'PM';
    return '${hour.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')} $period';
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6, horizontal: 12),
      child: Row(
        mainAxisAlignment:
            isUser ? MainAxisAlignment.start : MainAxisAlignment.end,
        children: [
          if (isUser)
            const CircleAvatar(
              backgroundColor: Colors.grey,
              child: Icon(Icons.person, color: Colors.white),
            ),
          Flexible(
            child: Container(
              margin: EdgeInsets.only(
                left: isUser ? 12 : 48,
                right: isUser ? 48 : 12,
              ),
              padding: const EdgeInsets.symmetric(vertical: 14, horizontal: 16),
              decoration: BoxDecoration(
                color: isUser ? Colors.white : const Color(0xFF003049),
                borderRadius: BorderRadius.only(
                  topLeft: const Radius.circular(20),
                  topRight: const Radius.circular(20),
                  bottomLeft: Radius.circular(isUser ? 0 : 20),
                  bottomRight: Radius.circular(isUser ? 20 : 0),
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.1),
                    blurRadius: 8,
                    offset: const Offset(2, 2),
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  isTyping
                      ? Row(
                        mainAxisSize: MainAxisSize.min,
                        children: const [
                          SizedBox(
                            width: 20,
                            height: 20,
                            child: CircularProgressIndicator(strokeWidth: 2),
                          ),
                          SizedBox(width: 10),
                          Text(
                            "Bot is thinking...",
                            style: TextStyle(color: Colors.white),
                          ),
                        ],
                      )
                      : Text(
                        text,
                        style: TextStyle(
                          color: isUser ? Colors.black : Colors.white,
                        ),
                      ),
                  if (!isTyping && timestamp != null)
                    Padding(
                      padding: const EdgeInsets.only(top: 4),
                      child: Text(
                        _formatTimestamp(timestamp!),
                        style: const TextStyle(
                          fontSize: 10,
                          color: Colors.grey,
                        ),
                      ),
                    ),
                ],
              ),
            ),
          ),
          if (!isUser)
            const CircleAvatar(
              backgroundColor: Colors.orange,
              child: Icon(Icons.restaurant_menu, color: Colors.white),
            ),
        ],
      ),
    );
  }
}   