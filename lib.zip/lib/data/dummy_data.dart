
import 'package:flutter/material.dart';

import 'package:meals_config_fire/models/category.dart';
import 'package:meals_config_fire/screens/meals.dart';
import 'package:meals_config_fire/models/meal.dart';

// Constants in Dart should be written in lowerCamelcase.
const availableCategories = [
  Category(
    id: 'c1',
    title: 'Italian',
    color: Colors.purple,
  ),
  Category(
    id: 'c2',
    title: 'Quick & Easy',
    color: Colors.red,
  ),
  Category(
    id: 'c3',
    title: 'Hamburgers',
    color: Colors.orange,
  ),
  Category(
    id: 'c4',
    title: 'German',
    color: Colors.amber,
  ),
  Category(
    id: 'c5',
    title: 'Light & Lovely',
    color: Colors.blue,
  ),
  Category(
    id: 'c6',
    title: 'Exotic',
    color: Colors.green,
  ),
  Category(
    id: 'c7',
    title: 'Breakfast',
    color: Colors.lightBlue,
  ),
  Category(
    id: 'c8',
    title: 'Asian',
    color: Colors.lightGreen,
  ),
  Category(
    id: 'c9',
    title: 'French',
    color: Colors.pink,
  ),
  Category(
    id: 'c10',
    title: 'Summer',
    color: Colors.teal,
  ),
];

const dummyMeals = [



  Meal(
  id: 'm4',
  categories: [
    'c8', // Asian
  ],
  title: 'Fragrant Chicken Biryani',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/8/89/Biryani---story_647_032917094114.jpg',
  duration: 90, // Total cooking time including marination
  ingredients: [
    '500g Chicken pieces',
    '2 cups Basmati rice',
    '2 large Onions, thinly sliced',
    '3-4 medium Tomatoes, chopped',
    '1 cup Yogurt',
    '2-3 Green chilies, slit',
    '1 inch Ginger, grated',
    '4 cloves Garlic, minced',
    '1 teaspoon Red chili powder',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    'A pinch of Saffron strands soaked in 2 tablespoons of milk',
    'Fresh coriander leaves, chopped',
    'Fresh mint leaves, chopped',
    '4 tablespoons Cooking oil or ghee',
    'Salt to taste',
    'Water as needed',
  ],
  steps: [
    'Marinate the chicken with yogurt, ginger, garlic, red chili powder, turmeric powder, coriander powder, cumin powder, and salt. Let it marinate for at least 30 minutes.',
    'Wash and soak the basmati rice for 20 minutes.',
    'Heat oil or ghee in a heavy-bottomed pot or Dutch oven. Add the sliced onions and fry until golden brown. Remove half of the fried onions and set aside for garnish.',
    'Add the marinated chicken to the pot and cook on medium heat until it is partially cooked.',
    'Add the chopped tomatoes and green chilies to the chicken and cook until the tomatoes soften and the oil starts to separate.',
    'In a separate pot, bring water to a boil with some salt. Add the soaked rice and cook until it is about 70% done (the grains should still be slightly firm). Drain the rice.',
    'Now, layer the biryani. Spread half of the partially cooked rice over the chicken in the pot.',
    'Sprinkle some chopped coriander and mint leaves over the rice layer.',
    'Carefully spread the remaining rice over the first layer.',
    'Pour the saffron milk over the rice.',
    'Scatter the reserved fried onions, chopped coriander, and mint leaves on top.',
    'Cover the pot tightly with a lid and cook on low heat (dum) for 15-20 minutes, or until the rice is fully cooked and the flavors have melded together.',
    'Gently fluff the biryani with a fork before serving. Serve hot with raita (yogurt dip) and salad.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: false,
),

Meal(
  id: 'm5',
  categories: [
    'c8', // Asian
  ],
  title: 'Spicy Chicken Karahi',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/b/be/Punjabi_Chicken_Karahi.JPG',
  duration: 60,
  ingredients: [
    '750g Chicken, cut into pieces',
    '3-4 medium Tomatoes, roughly chopped',
    '2-3 large Onions, roughly chopped',
    '2-3 Green chilies, slit',
    '1 inch Ginger, roughly chopped',
    '4-5 cloves Garlic, roughly chopped',
    '1 tablespoon Red chili powder (adjust to taste)',
    '1 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    '1/2 cup Cooking oil',
    'Fresh coriander leaves, chopped, for garnish',
    'Fresh ginger, julienned, for garnish',
    'Salt to taste',
    'Water as needed (very little)',
  ],
  steps: [
    'Heat oil in a karahi (wok) or a heavy-bottomed pan.',
    'Add the chopped onions and sauté until they turn light golden brown.',
    'Add the ginger and garlic and sauté for another minute until fragrant.',
    'Add the chicken pieces and cook on medium-high heat until they are lightly browned.',
    'Add the chopped tomatoes, red chili powder, turmeric powder, coriander powder, and cumin powder. Mix well.',
    'Cover the karahi and cook on medium heat until the tomatoes soften and break down, and the oil starts to separate from the masala (spice mixture). Stir occasionally.',
    'Add the slit green chilies and salt to taste. Continue to cook for another 10-15 minutes, stirring occasionally, until the chicken is fully cooked and the gravy has thickened to your desired consistency. Add a splash of water if the masala gets too dry, but the karahi is usually cooked with very little water.',
    'Sprinkle garam masala over the karahi and mix well.',
    'Garnish with fresh coriander leaves and julienned ginger.',
    'Serve hot with naan, roti, or rice.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true, // Traditionally no dairy, but be mindful of oil used
),
Meal(
  id: 'm6',
  categories: [
    'c8', // Asian
    'c7', // Breakfast (in some regions)
  ],
  title: 'Slow-Cooked Beef Nihari',
  affordability: Affordability.pricey,
  complexity: Complexity.hard,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/f/fe/%E0%A6%97%E0%A6%B0%E0%A7%81%E0%A6%B0_%E0%A6%AA%E0%A6%BE%E0%A6%AF%E0%A6%BC%E0%A6%BE_%E0%A6%A8%E0%A7%87%E0%A6%B9%E0%A6%BE%E0%A6%B0%E0%A6%BF.jpg',
  duration: 240, // This is a long-cooked dish!
  ingredients: [
    '1 kg Beef shank or stew meat, bone-in preferred',
    '2 large Onions, thinly sliced',
    '2 tablespoons Ginger-garlic paste',
    '2 tablespoons Nihari masala (available pre-made or homemade)',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1/2 cup Cooking oil or ghee',
    '4 tablespoons Wheat flour (atta)',
    '4-5 cups Beef broth or water',
    '2-3 Green chilies, slit',
    '1 inch Ginger, thinly sliced for garnish',
    'Fresh coriander leaves, chopped for garnish',
    'Lemon wedges for serving',
    'Salt to taste',
  ],
  steps: [
    'Heat oil or ghee in a large pot or Dutch oven.',
    'Add the thinly sliced onions and fry until golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Add the beef pieces and brown them on all sides.',
    'Stir in the nihari masala, red chili powder, and turmeric powder. Cook for a few minutes, stirring constantly.',
    'Add the beef broth or water and salt to taste. Bring to a boil, then reduce the heat to low, cover, and simmer for 3-4 hours, or until the beef is very tender and falling off the bone.',
    'In a separate small bowl, mix the wheat flour with a little bit of water to form a smooth slurry (no lumps).',
    'Gradually add the flour slurry to the simmering stew, stirring continuously to avoid lumps. The gravy will start to thicken.',
    'Continue to simmer for another 30-45 minutes, stirring occasionally, until the nihari reaches a thick, gravy-like consistency.',
    'Add the slit green chilies to the nihari in the last 10 minutes of cooking.',
    'Garnish with thinly sliced ginger and fresh coriander leaves.',
    'Serve hot with naan and lemon wedges.',
  ],
  isGlutenFree: false, // Due to the wheat flour
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true, // Traditionally no dairy, but be mindful of ghee used
),
Meal(
  id: 'm7',
  categories: [
    'c8', // Asian
  ],
  title: 'Rich and Savory Haleem',
  affordability: Affordability.affordable,
  complexity: Complexity.hard,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/f/f9/Haleem_2_by_Monir.jpg',
  duration: 180, // Long cooking time for the perfect texture
  ingredients: [
    '250g Beef or Mutton, boneless, cut into small pieces',
    '1 cup Wheat (dalia or cracked wheat)',
    '1/2 cup Mixed lentils (chana dal, masoor dal, moong dal)',
    '1/4 cup Barley',
    '2 medium Onions, finely chopped',
    '2 tablespoons Ginger-garlic paste',
    '1 tablespoon Haleem masala (available pre-made or homemade)',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    '1/2 cup Cooking oil or ghee',
    '4-5 cups Water or stock',
    'Fresh coriander leaves, chopped for garnish',
    'Fried onions (birista) for garnish',
    'Green chilies, chopped for garnish',
    'Ginger, julienned for garnish',
    'Lemon wedges for serving',
    'Salt to taste',
  ],
  steps: [
    'Wash and soak the wheat, lentils, and barley together in enough water for at least 4-6 hours, or preferably overnight.',
    'Heat oil or ghee in a large pot.',
    'Add the finely chopped onions and sauté until golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Add the beef or mutton pieces and cook until browned.',
    'Stir in the haleem masala, red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a few minutes, stirring constantly.',
    'Add the soaked wheat, lentils, and barley along with the soaking water (or fresh water/stock if needed). Add salt to taste.',
    'Bring the mixture to a boil, then reduce the heat to low, cover, and simmer for 2-3 hours, stirring occasionally to prevent sticking. The grains and meat should become very soft.',
    'Once the grains and meat are cooked through, use a wooden spoon, hand blender, or a traditional "ghota" (a wooden masher) to mash and blend the mixture until it reaches a smooth, porridge-like consistency. This step is crucial for the characteristic texture of haleem.',
    'Add garam masala and mix well. Continue to simmer for another 15-20 minutes.',
    'Garnish generously with fried onions (birista), chopped fresh coriander, chopped green chilies, and julienned ginger.',
    'Serve hot with lemon wedges and naan.',
  ],
  isGlutenFree: false, // Due to wheat and barley
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true, // Traditionally no dairy, but be mindful of ghee used
),
Meal(
  id: 'm8',
  categories: [
    'c8', // Asian
  ],
  title: 'Creamy Chicken Tikka Masala',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/5/58/CHICKEN_TIKKA_MASALA.jpg',
  duration: 75, // Includes marination time
  ingredients: [
    '500g Chicken breast or thighs, cut into bite-sized pieces',
    // For the marinade:
    '1/2 cup Yogurt',
    '1 tablespoon Ginger-garlic paste',
    '1 teaspoon Red chili powder',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Garam masala',
    '1 teaspoon Lemon juice',
    'Salt to taste',
    // For the sauce:
    '2 large Onions, finely chopped',
    '2-3 medium Tomatoes, pureed or finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    '1/2 cup Heavy cream or yogurt',
    '2 tablespoons Butter or oil',
    'Fresh coriander leaves, chopped for garnish',
    'Kasuri methi (dried fenugreek leaves), crushed (optional)',
    'Water as needed',
  ],
  steps: [
    // Marinating the chicken
    'In a bowl, mix together yogurt, ginger-garlic paste, red chili powder, turmeric powder, garam masala, lemon juice, and salt.',
    'Add the chicken pieces to the marinade, ensuring they are well coated.',
    'Cover the bowl and refrigerate for at least 30 minutes, or up to a few hours.',
    // Cooking the chicken
    'Preheat your grill or oven to a high temperature.',
    'Thread the marinated chicken pieces onto skewers (if grilling) or arrange them on a baking sheet.',
    'Grill or bake the chicken until it is cooked through and slightly charred, about 15-20 minutes.',
    // Making the sauce
    'While the chicken is cooking, heat butter or oil in a pan or pot.',
    'Add the finely chopped onions and sauté until golden brown.',
    'Add the ginger-garlic paste and sauté for another minute until fragrant.',
    'Stir in the tomato puree or chopped tomatoes, red chili powder, turmeric powder, coriander powder, and cumin powder. Cook until the tomatoes break down and the oil starts to separate.',
    'Add a little water if the sauce is too thick.',
    'Stir in the heavy cream or yogurt and garam masala. Cook on low heat for a few minutes, stirring occasionally.',
    'Add the cooked chicken tikka pieces to the sauce and mix well.',
    'Simmer for another 5-10 minutes to allow the flavors to meld.',
    'Garnish with fresh coriander leaves and crushed kasuri methi (if using).',
    'Serve hot with naan, roti, or rice.',
  ],
  isGlutenFree: true, // If served with rice
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: false, // Due to yogurt and cream
),
Meal(
  id: 'm9',
  categories: [
    'c8', // Asian
  ],
  title: 'Rich Mutton Korma',
  affordability: Affordability.luxurious,
  complexity: Complexity.challenging,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/4/47/Goat_Korma%2C_Butter_Chicken%2C_Cabbage_Stir-fry_with_Pilau_Rice_and_Teh_Tarik_-_Cafe_Zam_Zam_%28608627954%29.jpg',
  duration: 90, // Includes marination time
  ingredients: [
    '750g Mutton, cut into pieces (preferably with bone)',
    '1 cup Yogurt',
    '2 large Onions, finely chopped',
    '2 tablespoons Ginger-garlic paste',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    '4-5 Green cardamom pods',
    '3-4 Cloves',
    '1 inch Cinnamon stick',
    '2-3 Bay leaves',
    '1/4 cup Cashews, soaked in warm milk for 30 minutes',
    '2 tablespoons Poppy seeds (khashkhash), soaked in warm milk for 30 minutes',
    '1/4 cup Cooking oil or ghee',
    '2 tablespoons Fresh cream (optional)',
    'Fresh coriander leaves, chopped for garnish',
    'Rosewater or Kewra essence (a few drops, optional)',
    'Salt to taste',
    'Water as needed',
  ],
  steps: [
    'In a bowl, mix the mutton pieces with yogurt, ginger-garlic paste, red chili powder, turmeric powder, coriander powder, cumin powder, and salt. Marinate for at least 1 hour, or preferably longer.',
    'Grind the soaked cashews and poppy seeds into a smooth paste using the milk they were soaked in. Set aside.',
    'Heat oil or ghee in a heavy-bottomed pot.',
    'Add the whole spices: cardamom pods, cloves, cinnamon stick, and bay leaves. Sauté for a minute until fragrant.',
    'Add the finely chopped onions and fry until golden brown.',
    'Add the marinated mutton to the pot and cook on medium-high heat until it is browned on all sides.',
    'Stir in the cashew and poppy seed paste and cook for a few minutes, stirring continuously.',
    'Add a little water or stock if needed to prevent sticking. Cover the pot and simmer on low heat until the mutton is tender, about 45-60 minutes.',
    'Once the mutton is cooked, add the garam masala and mix well.',
    'If using, stir in the fresh cream for extra richness. Cook for another 5 minutes.',
    'Add a few drops of rosewater or kewra essence if desired for a fragrant touch.',
    'Garnish with fresh coriander leaves.',
    'Serve hot with naan, roti, paratha, or rice.',
  ],
  isGlutenFree: true, // If served with rice
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: false, // Due to yogurt, milk in paste, and cream
),
Meal(
  id: 'm10',
  categories: [
    'c8', // Asian
  ],
  title: 'Hearty Aloo Gosht',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/c/c3/Saloonay_Chawal_With_Aloo_Gosht.JPG',
  duration: 75,
  ingredients: [
    '500g Mutton or Beef, cut into medium pieces (with bone preferred)',
    '3-4 medium Potatoes, peeled and quartered',
    '2 medium Onions, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    '2-3 medium Tomatoes, chopped',
    '2-3 Green chilies, slit',
    '1/2 cup Cooking oil',
    'Fresh coriander leaves, chopped for garnish',
    'Water as needed',
    'Salt to taste',
  ],
  steps: [
    'Heat oil in a pot.',
    'Add the finely chopped onions and sauté until golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Add the mutton or beef pieces and cook on medium-high heat until browned on all sides.',
    'Stir in the red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a few minutes, stirring constantly.',
    'Add the chopped tomatoes and cook until they soften and the oil starts to separate from the masala.',
    'Add enough water to cover the meat. Bring to a boil, then reduce the heat to low, cover, and simmer until the meat is about halfway cooked (around 30-40 minutes for mutton, longer for beef).',
    'Add the peeled and quartered potatoes and slit green chilies to the pot. Add salt to taste.',
    'Continue to simmer, covered, until the potatoes are tender and the meat is fully cooked.',
    'Stir in the garam masala.',
    'Garnish with fresh coriander leaves.',
    'Serve hot with roti, naan, or rice.',
  ],
  isGlutenFree: true, // If served with rice
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true, // Traditionally no dairy
),
Meal(
  id: 'm11',
  categories: [
    'c8', // Asian
    'c10', // Summer (it's a light and often preferred meal in warmer months)
    'c5', // Light & Lovely
  ],
  title: 'Simple and Comforting Daal Chawal',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/7/79/C8-DPPxXsAEeCOy.jpg',
  duration: 45,
  ingredients: [
    // For the Daal (Lentils):
    '1 cup Yellow lentils (Moong Dal) or Red lentils (Masoor Dal), or a mix',
    '4 cups Water',
    '1 medium Onion, finely chopped',
    '1-2 medium Tomatoes, finely chopped',
    '1 teaspoon Ginger-garlic paste',
    '1/2 teaspoon Turmeric powder',
    '1/2 teaspoon Red chili powder (optional)',
    '1/4 teaspoon Cumin seeds',
    '1/4 teaspoon Mustard seeds',
    'A pinch of Asafoetida (hing) (optional)',
    '2 tablespoons Cooking oil or ghee',
    'Fresh coriander leaves, chopped for garnish',
    'Salt to taste',
    '1-2 Green chilies, slit (optional)',
    'Lemon juice (optional)',
    // For the Chawal (Rice):
    '1 cup Basmati rice',
    '2 cups Water',
    'Salt to taste (optional)',
  ],
  steps: [
    // Cooking the Daal:
    'Wash the lentils thoroughly and soak them in water for about 30 minutes.',
    'Drain the soaked lentils and add them to a pot with 4 cups of fresh water, turmeric powder, red chili powder (if using), and salt. Bring to a boil, then reduce heat and simmer until the lentils are soft and mushy (about 20-25 minutes). Skim off any foam that rises to the surface.',
    'While the lentils are simmering, heat oil or ghee in a small pan.',
    'Add cumin seeds and mustard seeds. Let them splutter.',
    'If using, add asafoetida (hing) and sauté for a few seconds.',
    'Add the finely chopped onion and sauté until golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Add the finely chopped tomatoes and cook until they soften.',
    'Pour this tempering (tarka) into the cooked lentils. Add slit green chilies (if using) and mix well. Simmer for another 5-10 minutes.',
    'Garnish with fresh coriander leaves and a squeeze of lemon juice (optional).',
    // Cooking the Chawal (Rice):
    'Wash the basmati rice thoroughly and soak it for about 20 minutes.',
    'Drain the soaked rice and add it to a pot with 2 cups of water and salt (if using).',
    'Bring to a boil, then reduce heat to low, cover, and simmer for 15-20 minutes, or until all the water is absorbed and the rice is cooked through.',
    'Fluff the rice with a fork before serving.',
    // Serving Daal Chawal:
    'Serve the hot daal with the fluffy rice. Its often enjoyed with a side of achar (pickle) and sometimes plain yogurt or salad.',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true, // If no ghee is used in tempering
),
Meal(
  id: 'm12',
  categories: [
    'c8', // Asian
  ],
  title: 'Tangy and Spicy Chana Masala',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/b/b1/Spiced_Chana_Kadala_Fry_Kadala_Masala_%2815914972565%29.jpg',
  duration: 60, // Includes soaking time for chickpeas
  ingredients: [
    '1 cup Dried chickpeas (chana)',
    '4 cups Water (for soaking)',
    '2 tablespoons Cooking oil',
    '1 large Onion, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '2 medium Tomatoes, finely chopped or pureed',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    '1/2 teaspoon Amchur powder (dried mango powder) or 1 tablespoon lemon juice',
    '1/4 teaspoon Asafoetida (hing) (optional)',
    '1-2 Green chilies, slit',
    'Fresh coriander leaves, chopped for garnish',
    'Salt to taste',
    '1 teaspoon Dried fenugreek leaves (kasuri methi), crushed (optional)',
    '1/2 teaspoon Baking soda (added while boiling chickpeas)',
  ],
  steps: [
    'Soak the dried chickpeas in 4 cups of water overnight or for at least 6-8 hours.',
    'Drain the soaked chickpeas and rinse them well.',
    'In a pressure cooker or a pot, add the soaked chickpeas, fresh water (enough to cover them by about an inch), baking soda, and salt to taste. Pressure cook for 4-5 whistles or simmer in a pot until the chickpeas are very tender (about 45-60 minutes). Drain the chickpeas, reserving some of the cooking liquid.',
    'Heat oil in a pan or pot.',
    'Add asafoetida (hing), if using, and let it sizzle.',
    'Add the finely chopped onion and sauté until golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Add the finely chopped or pureed tomatoes and cook until they soften and the oil starts to separate.',
    'Stir in the red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a minute, stirring constantly.',
    'Add the boiled chickpeas and mix well with the masala. Add some of the reserved cooking liquid if the curry is too thick.',
    'Add garam masala, amchur powder (or lemon juice), slit green chilies, and salt to taste. Mix well.',
    'Crush the dried fenugreek leaves (kasuri methi) between your palms and add them to the curry (if using).',
    'Simmer for another 5-10 minutes to allow the flavors to meld.',
    'Garnish with fresh coriander leaves.',
    'Serve hot with naan, roti, paratha, or rice.',
  ],
  isGlutenFree: true, // If served with rice
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm13',
  categories: [
    'c8', // Asian
  ],
  title: 'Savory Keema Matar',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/7/73/Matar_keema1.jpg',
  duration: 50,
  ingredients: [
    '500g Minced meat (Keema) - Chicken, Beef, or Mutton',
    '1 cup Green peas (Matar), fresh or frozen',
    '2 medium Onions, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '2 medium Tomatoes, finely chopped or pureed',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    '1/4 teaspoon Asafoetida (hing) (optional)',
    '1-2 Green chilies, finely chopped',
    'Fresh coriander leaves, chopped for garnish',
    '2 tablespoons Cooking oil',
    'Salt to taste',
    'Water as needed (very little)',
  ],
  steps: [
    'Heat oil in a pan or pot.',
    'Add asafoetida (hing), if using, and let it sizzle.',
    'Add the finely chopped onions and sauté until golden brown.',
    'Add the minced meat (keema) and cook on medium-high heat, breaking it up with a spoon, until it changes color and is no longer pink.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Stir in the red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a minute, stirring constantly.',
    'Add the finely chopped or pureed tomatoes and cook until they soften and the oil starts to separate.',
    'Add the green peas (matar) and mix well.',
    'Add salt to taste and a little bit of water (if needed to prevent sticking). Cover and simmer on low heat until the peas are tender and the keema is fully cooked, about 15-20 minutes.',
    'Stir in the garam masala and finely chopped green chilies.',
    'Garnish with fresh coriander leaves.',
    'Serve hot with roti, naan, paratha, or rice.',
  ],
  isGlutenFree: true, // If served with rice
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true,
),
Meal(
  id: 'm14',
  categories: [
    'c8', // Asian
    'c6', // Exotic (due to its unique cooking method)
  ],
  title: 'Balochi Sajji',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging, // Requires specific cooking setup
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/thumb/f/f1/Balochi_Sajji.jpg/800px-Balochi_Sajji.jpg',
  duration: 120, // Includes marination and roasting time
  ingredients: [
    '1 whole Chicken (about 1.5 - 2 kg) or Lamb leg/shoulder (about 2 kg)',
    '2-3 tablespoons Coarse salt',
    '1 tablespoon Black pepper, freshly ground',
    '1 teaspoon Cumin seeds, crushed (optional)',
    'Lemon wedges for serving',
  ],
  steps: [
    'Clean the whole chicken or lamb thoroughly. Make deep slits all over the meat to allow the seasoning to penetrate.',
    'In a bowl, mix together the coarse salt, freshly ground black pepper, and crushed cumin seeds (if using).',
    'Generously rub the salt and pepper mixture all over the chicken or lamb, ensuring it gets into the slits. You can also stuff some of the seasoning inside the cavity.',
    'Let the meat marinate for at least 2-3 hours, or preferably overnight in the refrigerator.',
    'Traditionally, Sajji is cooked over an open fire or charcoal grill. You will need a long skewer or rod to impale the marinated meat.',
    'Prepare a charcoal fire, ensuring you have hot embers and not just flames.',
    'Securely impale the marinated chicken or lamb onto the skewer.',
    'Slowly roast the meat over the hot embers, rotating it frequently to ensure even cooking. This process can take anywhere from 1 to 2 hours depending on the size of the meat and the heat of the fire. The meat is done when it is cooked through and the skin is crispy and golden brown.',
    'Alternatively, if you don\'t have an open fire setup, you can try roasting it in a very hot oven (200°C or 400°F) on a rotisserie or a wire rack with a tray underneath to catch drippings. The cooking time will still be significant.',
    'Once cooked, remove the Sajji from the heat and let it rest for a few minutes before carving or serving.',
    'Serve hot with traditional Balochi "kaak" (a type of hard, plain bread) or naan, and lemon wedges.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true,
),
// Meal(
//   id: 'm15',
//   categories: [
//     'c8', // Asian
//     'c7', // Breakfast (in some regions)
//   ],
//   title: 'Slow-Cooked Paya (Trotter Stew)',
//   affordability: Affordability.affordable,
//   complexity: Complexity.hard, // Requires long cooking time
//   imageUrl:
//       'https://upload.wikimedia.org/wikipedia/commons/thumb/4/49/Paya_at_a_restaurant.jpg/800px-Paya_at_a_restaurant.jpg',
//   duration: 300, // This is a very slow-cooked dish!
//   ingredients: [
//     '4 Goat or Lamb trotters (paya), cleaned and cut into pieces',
//     '2 large Onions, roughly chopped',
//     '2 tablespoons Ginger-garlic paste',
//     '1 teaspoon Red chili powder (adjust to taste)',
//     '1/2 teaspoon Turmeric powder',
//     '1 tablespoon Coriander powder',
//     '1/2 teaspoon Cumin powder',
//     '1/4 teaspoon Garam masala',
//     '2-3 Black cardamom pods',
//     '3-4 Green cardamom pods',
//     '4-5 Cloves',
//     '1-inch Cinnamon stick',
//     '2-3 Bay leaves',
//     'Salt to taste',
//     '4-6 cups Water or stock',
//     // Optional tempering (Tarka):
//     '2 tablespoons Oil or ghee',
//     '1 medium Onion, thinly sliced',
//     '1 teaspoon Kashmiri red chili powder (for color)',
//     'Fresh coriander leaves, chopped for garnish',
//     'Ginger, julienned for garnish',
//     'Lemon wedges for serving',
//   ],
//   steps: [
//     'Thoroughly clean the trotters under running water. You might need to singe any remaining hair and scrub them well.',
//     'In a large pot or pressure cooker, add the trotters, roughly chopped onions, ginger-garlic paste, red chili powder, turmeric powder, coriander powder, cumin powder, garam masala, black cardamom pods, green cardamom pods, cloves, cinnamon stick, bay leaves, and salt.',
//     'Add enough water or stock to cover the trotters generously (about 4-6 cups).',
//     'If using a pressure cooker, cook on high pressure for about 8-10 whistles, then reduce the heat and simmer for another 30-45 minutes. If cooking in a regular pot, bring to a boil, then reduce the heat to the lowest setting, cover, and simmer for 4-6 hours, or until the trotters are extremely tender and the meat is falling off the bones. The broth should be thick and gelatinous.',
//     'Once cooked, remove the trotters from the pot. Strain the broth through a fine sieve to remove the whole spices and onion pieces. Return the trotters to the strained broth.',
//     'For the optional tempering (tarka): Heat oil or ghee in a small pan. Add thinly sliced onions and fry until golden brown and crispy.',
//     'Remove the pan from the heat and stir in Kashmiri red chili powder for color.',
//     'Pour the tempering over the paya stew.',
//     'Garnish with fresh coriander leaves and julienned ginger.',
//     'Serve hot with naan and lemon wedges. The gelatinous broth is the highlight of this dish!',
//   ],
//   isGlutenFree: true, // If served without naan
//   isVegan: false,
//   isVegetarian: false,
//   isLactoseFree: true, // Traditionally no dairy, but be mindful of ghee used in tarka
// ),
// Meal(
//   id: 'm16',
//   categories: [
//     'c8', // Asian
//   ],
//   title: 'Creamy Chicken Handi',
//   affordability: Affordability.pricey,
//   complexity: Complexity.challenging, // Achieving the right creamy texture
//   imageUrl:
//       'https://upload.wikimedia.org/wikipedia/commons/thumb/4/41/Chicken_Handi.jpg/800px-Chicken_Handi.jpg',
//   duration: 65,
//   ingredients: [
//     '750g Chicken, cut into pieces (boneless or with bone)',
//     '2 medium Onions, finely chopped',
//     '2 tablespoons Ginger-garlic paste',
//     '3-4 medium Tomatoes, pureed or finely chopped',
//     '1 teaspoon Red chili powder (adjust to taste)',
//     '1/2 teaspoon Turmeric powder',
//     '1 tablespoon Coriander powder',
//     '1 teaspoon Cumin powder',
//     '1/2 teaspoon Garam masala',
//     '1/2 cup Yogurt',
//     '1/4 cup Fresh cream',
//     '2-3 Green chilies, slit',
//     'Fresh coriander leaves, chopped for garnish',
//     '1 tablespoon Dried fenugreek leaves (kasuri methi), crushed',
//     '2-3 tablespoons Cooking oil or butter',
//     'Salt to taste',
//     'A pinch of saffron strands soaked in 1 tablespoon of milk (optional)',
//   ],
//   steps: [
//     'Heat oil or butter in a heavy-bottomed pot or preferably a clay handi.',
//     'Add the finely chopped onions and sauté until golden brown.',
//     'Add the ginger-garlic paste and sauté for a minute until fragrant.',
//     'Add the chicken pieces and cook on medium-high heat until they are lightly browned.',
//     'Stir in the red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a minute, stirring constantly.',
//     'Add the tomato puree or chopped tomatoes and cook until they soften and the oil starts to separate.',
//     'Reduce the heat to low and stir in the yogurt. Cook for a few minutes, stirring continuously to prevent curdling.',
//     'Add salt to taste and the slit green chilies. Cover and simmer for 15-20 minutes, or until the chicken is cooked through.',
//     'Stir in the garam masala and crushed kasuri methi.',
//     'Pour in the fresh cream and the saffron milk (if using). Mix gently and cook for another 5 minutes on low heat.',
//     'Garnish generously with fresh coriander leaves.',
//     'Serve hot with naan, roti, or rice. The traditional way is to serve it directly from the handi.',
//   ],
//   isGlutenFree: true, // If served with rice
//   isVegan: false,
//   isVegetarian: false,
//   isLactoseFree: false, // Due to yogurt and cream
// ),
Meal(
  id: 'm17',
  categories: [
    'c8', // Asian
  ],
  title: 'Rich and Flavorful Bhuna Gosht',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging, // Requires careful bhunai
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/b/b9/Bhuna_Gosht.jpg',
  duration: 90,
  ingredients: [
    '750g Mutton, cut into medium pieces (preferably with bone)',
    '2 large Onions, finely chopped',
    '2 tablespoons Ginger-garlic paste',
    '2-3 medium Tomatoes, finely chopped',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '2 tablespoons Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    '1/4 teaspoon Black pepper powder',
    '2-3 Green cardamom pods',
    '3-4 Cloves',
    '1-inch Cinnamon stick',
    '2-3 Bay leaves',
    '1/2 cup Yogurt (optional, for tenderizing)',
    '3-4 tablespoons Cooking oil',
    'Fresh coriander leaves, chopped for garnish',
    'Fresh ginger, julienned for garnish',
    'Salt to taste',
    'A few tablespoons of water or stock (if needed)',
  ],
  steps: [
    'Heat oil in a heavy-bottomed pot.',
    'Add the whole spices: cardamom pods, cloves, cinnamon stick, and bay leaves. Sauté for a minute until fragrant.',
    'Add the finely chopped onions and fry until golden brown.',
    'Add the ginger-garlic paste and sauté for another minute until the raw smell disappears.',
    'Add the mutton pieces and cook on medium-high heat until they are browned on all sides.',
    'Stir in the red chili powder, turmeric powder, coriander powder, cumin powder, and black pepper powder. Cook for a few minutes, stirring constantly, until the oil starts to separate from the spices.',
    'Add the finely chopped tomatoes and cook until they soften and break down.',
    'If using, stir in the yogurt and cook until it is well incorporated and the water has evaporated. This helps in tenderizing the meat.',
    'Now begins the crucial "bhunai" process. Continue to cook on medium heat, stirring frequently, until the oil separates completely from the masala and the meat is well-coated and looks slightly dry but deeply browned. This step intensifies the flavors.',
    'Add salt to taste and garam masala. Mix well.',
    'If the mixture becomes too dry and starts to stick, add a few tablespoons of hot water or stock, but the aim is to keep this a semi-dry dish.',
    'Cover the pot and simmer on low heat until the mutton is tender, about 30-45 minutes, or longer depending on the cut of meat.',
    'Garnish with fresh coriander leaves and julienned ginger.',
    'Serve hot with roti, naan, or paratha.',
  ],
  isGlutenFree: true, // If served with rice
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true, // If yogurt is not used
),
Meal(
  id: 'm18',
  categories: [
    'c8', // Asian
  ],
  title: 'Tangy Pakistani Fish Curry',
  affordability: Affordability.pricey,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/6/6c/Fish_curry_Sari_Ratu.jpg',
  duration: 40,
  ingredients: [
    '500g Firm white fish fillets (like cod, snapper, or tilapia), cut into pieces',
    '2 medium Onions, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '2 medium Tomatoes, finely chopped or pureed',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Fenugreek seeds (methi dana)',
    'A pinch of Asafoetida (hing) (optional)',
    '2-3 Green chilies, slit',
    'Fresh coriander leaves, chopped for garnish',
    '2 tablespoons Cooking oil',
    '1 tablespoon Tamarind pulp (imli) soaked in 1/4 cup warm water and strained, or 1 tablespoon lemon juice',
    'Salt to taste',
    'A few curry leaves (karhi patta) (optional)',
    '1/2 teaspoon Mustard seeds (rai) (optional)',
  ],
  steps: [
    'Marinate the fish pieces with a pinch of turmeric powder and salt for about 15 minutes.',
    'Heat oil in a pan.',
    'If using, add mustard seeds and fenugreek seeds. Let them splutter.',
    'Add asafoetida (hing) and curry leaves (if using). Sauté for a few seconds.',
    'Add the finely chopped onions and sauté until light golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Stir in the red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a few seconds, stirring constantly.',
    'Add the finely chopped or pureed tomatoes and cook until they soften and the oil starts to separate.',
    'Add the strained tamarind pulp (or lemon juice) and salt to taste. Mix well and bring to a gentle simmer.',
    'Carefully add the marinated fish pieces to the gravy. Cover the pan and simmer gently for about 8-10 minutes, or until the fish is cooked through and flakes easily. Avoid overcooking the fish.',
    'Add the slit green chilies and garnish with fresh coriander leaves.',
    'Serve hot with rice or roti.',
  ],
  isGlutenFree: true, // If served with rice
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true,
),
Meal(
  id: 'm19',
  categories: [
    'c8', // Asian
  ],
  title: 'Fragrant Chicken Pulao',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/4/45/Zafrani_Pulao.jpg',
  duration: 60,
  ingredients: [
    '500g Chicken, cut into pieces',
    '2 cups Basmati rice',
    '2 medium Onions, thinly sliced',
    '1 tablespoon Ginger-garlic paste',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    '2-3 Green cardamom pods',
    '3-4 Cloves',
    '1-inch Cinnamon stick',
    '1-2 Bay leaves',
    '1/4 cup Yogurt (optional, for tenderizing chicken)',
    '2-3 tablespoons Cooking oil or ghee',
    '4 cups Chicken broth or water',
    'Fresh coriander leaves, chopped for garnish',
    'Mint leaves, chopped for garnish (optional)',
    'Salt to taste',
  ],
  steps: [
    'Wash and soak the basmati rice for 20 minutes.',
    'Heat oil or ghee in a heavy-bottomed pot.',
    'Add the whole spices: cardamom pods, cloves, cinnamon stick, and bay leaves. Sauté for a minute until fragrant.',
    'Add the thinly sliced onions and fry until golden brown.',
    'Add the ginger-garlic paste and sauté for another minute.',
    'Add the chicken pieces and cook until they are lightly browned.',
    'Stir in the red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a minute.',
    'If using yogurt, add it now and cook until the water evaporates.',
    'Add the chicken broth or water and salt to taste. Bring to a boil.',
    'Add the soaked and drained rice. Stir gently once.',
    'Reduce the heat to low, cover the pot tightly, and let it simmer for 15-20 minutes, or until all the liquid is absorbed and the rice is cooked through.',
    'Once cooked, remove from heat and let it rest for 5-10 minutes without opening the lid.',
    'Gently fluff the pulao with a fork.',
    'Garnish with fresh coriander leaves and mint leaves (if using).',
    'Serve hot with raita (yogurt dip) and salad.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true, // If yogurt is not used
),
Meal(
  id: 'm20',
  categories: [
    'c8', // Asian
    'c5', // Light & Lovely
  ],
  title: 'Fragrant Matar Pulao (Peas Pulao)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/1/18/Matar_Pulao%2C_boondi_raita%2C_dry_roasted-papad.JPG',
  duration: 40,
  ingredients: [
    '2 cups Basmati rice',
    '1 cup Green peas (matar), fresh or frozen',
    '1 medium Onion, thinly sliced',
    '1 tablespoon Ginger-garlic paste',
    '1 teaspoon Cumin seeds',
    '1/2 teaspoon Turmeric powder',
    '1/2 teaspoon Garam masala',
    '2-3 Green cardamom pods',
    '3-4 Cloves',
    '1-inch Cinnamon stick',
    '1-2 Bay leaves',
    '2 tablespoons Cooking oil or ghee',
    '4 cups Vegetable broth or water',
    'Fresh coriander leaves, chopped for garnish',
    'Mint leaves, chopped for garnish (optional)',
    'Salt to taste',
  ],
  steps: [
    'Wash the basmati rice thoroughly and soak it for 20 minutes.',
    'Heat oil or ghee in a heavy-bottomed pot.',
    'Add the whole spices: cumin seeds, cardamom pods, cloves, cinnamon stick, and bay leaves. Sauté for a minute until fragrant.',
    'Add the thinly sliced onions and fry until light golden brown.',
    'Add the ginger-garlic paste and sauté for another minute.',
    'Add the green peas (matar) and sauté for 2-3 minutes.',
    'Stir in the turmeric powder and garam masala. Cook for a few seconds.',
    'Add the vegetable broth or water and salt to taste. Bring to a boil.',
    'Add the soaked and drained rice. Stir gently once.',
    'Reduce the heat to low, cover the pot tightly, and let it simmer for 15-20 minutes, or until all the liquid is absorbed and the rice is cooked through.',
    'Once cooked, remove from heat and let it rest for 5-10 minutes without opening the lid.',
    'Gently fluff the pulao with a fork.',
    'Garnish with fresh coriander leaves and mint leaves (if using).',
    'Serve hot as a standalone dish or as a side with a curry or raita.',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm21',
  categories: [
    'c8', // Asian
  ],
  title: 'Fragrant Chicken Yakhni Pulao',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging, // Making the perfect yakhni
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/e/ea/Yakhni_Rice.jpg',
  duration: 75, // Includes time for making the yakhni
  ingredients: [
    '500g Chicken, cut into pieces',
    '2 cups Basmati rice',
    // For the Yakhni (Stock):
    '4 cups Water',
    '1 medium Onion, roughly chopped',
    '1 inch Ginger, roughly chopped',
    '4-5 cloves Garlic, roughly chopped',
    '2-3 Green cardamom pods',
    '3-4 Black peppercorns',
    '1-inch Cinnamon stick',
    '1 Bay leaf',
    '1 teaspoon Coriander seeds, crushed',
    '1/2 teaspoon Fennel seeds, crushed',
    'Salt to taste',
    // For the Pulao:
    '2 tablespoons Cooking oil or ghee',
    '1 medium Onion, thinly sliced',
    '1/4 teaspoon Cumin seeds',
    'A pinch of saffron strands soaked in 2 tablespoons of milk (optional)',
    'Fresh coriander leaves, chopped for garnish',
    'Mint leaves, chopped for garnish (optional)',
  ],
  steps: [
    // Making the Yakhni (Stock):
    'In a pot, combine the chicken pieces, water, roughly chopped onion, ginger, garlic, green cardamom pods, black peppercorns, cinnamon stick, bay leaf, crushed coriander seeds, crushed fennel seeds, and salt.',
    'Bring to a boil, then reduce heat and simmer gently for 30-40 minutes, or until the chicken is cooked through. Skim off any foam that rises to the surface.',
    'Strain the yakhni (stock) through a fine sieve, reserving both the stock and the cooked chicken pieces. Discard the whole spices and vegetables used for the stock.',
    // Preparing the Pulao:
    'Wash the basmati rice thoroughly and soak it for 20 minutes.',
    'Heat oil or ghee in a heavy-bottomed pot.',
    'Add the cumin seeds and let them splutter.',
    'Add the thinly sliced onion and fry until light golden brown.',
    'Add the reserved cooked chicken pieces and sauté for a few minutes.',
    'Add the soaked and drained rice. Stir gently.',
    'Pour the strained yakhni (stock) into the pot (you should have about 3.5 - 4 cups of stock; add more water if needed to reach this amount). Add salt to taste, keeping in mind that the stock already has some salt.',
    'Bring the mixture to a boil.',
    'Reduce the heat to low, cover the pot tightly, and let it simmer for 15-20 minutes, or until all the liquid is absorbed and the rice is cooked through.',
    'Once cooked, remove from heat and let it rest for 5-10 minutes without opening the lid.',
    'Gently fluff the pulao with a fork. Sprinkle with saffron milk (if using), fresh coriander leaves, and mint leaves (if using).',
    'Serve hot with raita (yogurt dip) and salad.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true,
),
Meal(
  id: 'm22',
  categories: [
    'c8', // Asian
  ],
  title: 'Rich Beef Biryani',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/5/54/Food-Beef-Biryani-2.jpg',
  duration: 120, // Longer cooking time for tender beef
  ingredients: [
    '750g Beef, cut into 1-inch cubes',
    '2 cups Basmati rice',
    '3 large Onions, thinly sliced',
    '3-4 medium Tomatoes, chopped',
    '1 cup Yogurt',
    '2-3 Green chilies, slit',
    '2 tablespoons Ginger-garlic paste',
    '1 tablespoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    'A pinch of Saffron strands soaked in 2 tablespoons of milk',
    'Fresh coriander leaves, chopped',
    'Fresh mint leaves, chopped',
    '4 tablespoons Cooking oil or ghee',
    'Salt to taste',
    'Water as needed',
    '2-3 medium Potatoes, peeled and halved (optional)',
  ],
  steps: [
    'Marinate the beef with yogurt, ginger-garlic paste, red chili powder, turmeric powder, coriander powder, cumin powder, and salt. Let it marinate for at least 2 hours, or preferably overnight.',
    'Wash and soak the basmati rice for 20 minutes.',
    'Heat oil or ghee in a heavy-bottomed pot or Dutch oven. Add the sliced onions and fry until golden brown. Remove half of the fried onions and set aside for garnish.',
    'Add the marinated beef to the pot and cook on medium-high heat until it is browned and the water released by the beef has mostly evaporated.',
    'Add the chopped tomatoes and green chilies to the beef and cook until the tomatoes soften and the oil starts to separate from the masala. You can also add the optional potatoes at this stage.',
    'In a separate pot, bring water to a boil with some salt. Add the soaked rice and cook until it is about 70% done (the grains should still be slightly firm). Drain the rice.',
    'Now, layer the biryani. Spread half of the partially cooked rice over the beef in the pot.',
    'Sprinkle some chopped coriander and mint leaves over the rice layer.',
    'Carefully spread the remaining rice over the first layer.',
    'Pour the saffron milk over the rice.',
    'Scatter the reserved fried onions, chopped coriander, and mint leaves on top.',
    'Cover the pot tightly with a lid and cook on low heat (dum) for 25-30 minutes, or until the rice is fully cooked and the flavors have melded together.',
    'Gently fluff the biryani with a fork before serving. Serve hot with raita (yogurt dip) and salad.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: false,
),
Meal(
  id: 'm23',
  categories: [
    'c8', // Asian
    'c7', // Breakfast (often eaten with eggs or other dishes)
  ],
  title: 'Simple Whole Wheat Roti/Chapati',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/8/81/Wheat_Roti_2.jpg',
  duration: 20, // For making a batch
  ingredients: [
    '2 cups Whole wheat flour (atta)',
    'About 1 cup Water (may vary)',
    'A pinch of salt (optional)',
    'Ghee or oil for brushing (optional)',
  ],
  steps: [
    'In a large bowl or a flat dish, add the whole wheat flour and salt (if using).',
    'Gradually add water, a little at a time, and mix with your fingers until a soft, smooth dough forms. The dough should not be sticky.',
    'Knead the dough for 5-7 minutes until it becomes elastic and smooth.',
    'Cover the dough with a damp cloth and let it rest for at least 15-20 minutes.',
    'Divide the dough into small, equal-sized balls (about the size of a golf ball).',
    'Take one dough ball and flatten it slightly between your palms.',
    'Dust a rolling surface and the dough ball with some dry whole wheat flour.',
    'Using a rolling pin, roll out the dough ball into a thin, circular shape (about 6-7 inches in diameter). Try to keep it as even as possible.',
    'Heat a flat griddle (tawa) over medium-high heat. Once the tawa is hot, place the rolled-out roti on it.',
    'Cook for about 30-45 seconds on each side, or until small bubbles start to appear and light brown spots form.',
    'Using tongs, remove the roti from the tawa and place it directly over an open flame (gas stove) for a few seconds on each side. This will make it puff up.',
    'Alternatively, you can gently press the edges of the roti on the hot tawa with a clean cloth to make it puff up.',
    'Once puffed, remove the roti from the flame or tawa. Brush with a little ghee or oil (optional) while its still hot to keep it soft.',
    'Repeat the process with the remaining dough balls.',
    'Serve hot with your favorite Pakistani curries or sabzis.',
  ],
  isGlutenFree: false,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm24',
  categories: [
    'c8', // Asian
  ],
  title: 'Soft and Delicious Naan',
  affordability: Affordability.affordable,
  complexity: Complexity.challenging, // Getting the texture right at home
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/2/22/Naan_is_a_flatbread_found_in_mainly_of_Indian_subcontinent.jpg',
  duration: 90, // Includes dough rising time
  ingredients: [
    '2 cups All-purpose flour (maida)',
    '1 teaspoon Instant dry yeast',
    '1 teaspoon Sugar',
    '1/2 teaspoon Salt',
    '1/4 cup Yogurt',
    '1/4 cup Milk, lukewarm',
    '2-3 tablespoons Water, lukewarm (may vary)',
    '2 tablespoons Oil or melted butter, plus more for brushing',
    'Optional: Garlic, chopped; Cilantro, chopped; Nigella seeds (kalonji)',
  ],
  steps: [
    'In a large bowl, whisk together the all-purpose flour, instant dry yeast, sugar, and salt.',
    'Add the yogurt, lukewarm milk, and oil or melted butter. Mix well.',
    'Gradually add lukewarm water, a little at a time, and mix until a soft, slightly sticky dough forms.',
    'Turn the dough out onto a lightly floured surface and knead for 8-10 minutes until it becomes smooth and elastic.',
    'Place the dough in a lightly oiled bowl, turning to coat. Cover the bowl with a damp cloth and let it rise in a warm place for at least 1-2 hours, or until doubled in size.',
    'Once the dough has risen, punch it down gently to release the air.',
    'Divide the dough into 6-8 equal-sized balls.',
    'Take one dough ball and roll it out into an oval or round shape, about 1/4 inch thick.',
    'Optional: Brush the surface of the naan with water and sprinkle with chopped garlic, cilantro, and/or nigella seeds.',
    // Cooking on a Tawa (Griddle):
    'Heat a heavy flat griddle (tawa) over medium-high heat. Once hot, place the naan on the tawa (watered side down if you added toppings).',
    'Cook for 1-2 minutes until small bubbles appear on the surface.',
    'Flip the naan and cook for another 1-2 minutes until the bottom is lightly browned.',
    'Using tongs, carefully lift the naan and cook it directly over an open flame (gas stove) for a few seconds on each side until it puffs up and gets slightly charred spots.',
    'Brush with melted butter or oil and serve hot.',
    // Cooking in an Oven (if no tandoor or open flame):
    'Preheat your oven to its highest setting (usually 230-250°C or 450-500°F) with a baking stone or inverted baking sheet inside.',
    'Place the rolled-out naan on the hot baking stone or sheet.',
    'Bake for 2-4 minutes, or until the naan is puffed up and lightly golden brown. Keep a close eye on it as it can burn quickly at high temperatures.',
    'Brush with melted butter or oil and serve hot.',
    'Repeat with the remaining dough balls.',
  ],
  isGlutenFree: false,
  isVegan: false, // Contains yogurt and milk
  isVegetarian: true,
  isLactoseFree: false, // Contains yogurt and milk
),
Meal(
  id: 'm25',
  categories: [
    'c8', // Asian
    'c7', // Breakfast
  ],
  title: 'Flaky Plain Paratha',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/0/0b/Paratha_is_a_dough_fried_flatbread_native_to_India_and_Pakistan.jpg',
  duration: 30, // For making a batch
  ingredients: [
    '2 cups Whole wheat flour (atta)',
    'About 1/2 cup Water (may vary)',
    '1/4 cup Ghee or oil, plus more for cooking',
    'A pinch of salt (optional)',
  ],
  steps: [
    'In a large bowl or a flat dish, add the whole wheat flour and salt (if using).',
    'Gradually add water, a little at a time, and mix with your fingers until a soft, smooth dough forms. The dough should not be sticky.',
    'Knead the dough for 5-7 minutes until it becomes elastic and smooth.',
    'Cover the dough with a damp cloth and let it rest for at least 15-20 minutes.',
    'Divide the dough into small, equal-sized balls (about the size of a small lime).',
    'Take one dough ball and flatten it slightly between your palms.',
    'Dust a rolling surface and the dough ball with some dry whole wheat flour.',
    'Roll out the dough ball into a thin circle (about 4-5 inches in diameter).',
    'Spread some ghee or oil evenly over the rolled-out circle.',
    'Fold the circle in half to form a semicircle. Spread some more ghee or oil on the semicircle.',
    'Fold the semicircle in half again to form a triangle (or you can roll it into a spiral shape if you prefer a different layering).',
    'Dust the triangular dough with some dry flour and gently roll it out again into a larger triangle (or circle if you rolled it into a spiral), about 6-7 inches in diameter and not too thin.',
    'Heat a flat griddle (tawa) over medium heat.',
    'Place the rolled-out paratha on the hot tawa.',
    'Cook for 1-2 minutes on each side, or until light brown spots start to appear.',
    'Drizzle some more ghee or oil around the edges of the paratha.',
    'Flip the paratha and cook the other side until it turns golden brown and crispy, pressing gently with a spatula to ensure even cooking and flakiness.',
    'Repeat the process with the remaining dough balls.',
    'Serve hot with your favorite Pakistani curries, eggs, yogurt, or pickles.',
  ],
  isGlutenFree: false,
  isVegan: true, // If oil is used instead of ghee
  isVegetarian: true,
  isLactoseFree: true, // If oil is used instead of ghee
),
Meal(
  id: 'm26',
  categories: [
    'c8', // Asian
  ],
  title: 'Soft Roghani Naan with Sesame Seeds',
  affordability: Affordability.affordable,
  complexity: Complexity.challenging, // Getting the soft texture and perfect bake
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/c/c5/Naan_shiva.jpg',
  duration: 100, // Includes dough rising time
  ingredients: [
    '2 cups All-purpose flour (maida)',
    '1 teaspoon Instant dry yeast',
    '1 teaspoon Sugar',
    '1/2 teaspoon Salt',
    '1/4 cup Yogurt',
    '1/4 cup Milk, lukewarm',
    '2-3 tablespoons Water, lukewarm (may vary)',
    '2 tablespoons Oil or melted butter',
    '2 tablespoons Sesame seeds (til)',
    'Oil or butter for brushing',
  ],
  steps: [
    'In a large bowl, whisk together the all-purpose flour, instant dry yeast, sugar, and salt.',
    'Add the yogurt, lukewarm milk, and oil or melted butter. Mix well.',
    'Gradually add lukewarm water, a little at a time, and mix until a soft, slightly sticky dough forms.',
    'Turn the dough out onto a lightly floured surface and knead for 8-10 minutes until it becomes smooth and elastic.',
    'Place the dough in a lightly oiled bowl, turning to coat. Cover the bowl with a damp cloth and let it rise in a warm place for at least 1-2 hours, or until doubled in size.',
    'Once the dough has risen, punch it down gently to release the air.',
    'Divide the dough into 6-8 equal-sized balls.',
    'Take one dough ball and gently roll it out into an oval or round shape, about 1/4 inch thick.',
    'Brush the surface of the rolled-out naan lightly with water or milk.',
    'Sprinkle a generous amount of sesame seeds evenly over the brushed surface. Gently press them down so they adhere.',
    // Cooking on a Tawa (Griddle):
    'Heat a heavy flat griddle (tawa) over medium-high heat. Once hot, place the naan (sesame seed side up) on the tawa.',
    'Cook for 1-2 minutes until small bubbles appear on the surface.',
    'Flip the naan and cook for another 1-2 minutes until the bottom is lightly browned.',
    'Using tongs, carefully lift the naan and cook it directly over an open flame (gas stove) for a few seconds on each side until it puffs up and gets slightly charred spots.',
    'Brush with melted butter or oil and serve hot.',
    // Cooking in an Oven (if no tandoor or open flame):
    'Preheat your oven to its highest setting (usually 230-250°C or 450-500°F) with a baking stone or inverted baking sheet inside.',
    'Place the rolled-out naan (sesame seed side up) on the hot baking stone or sheet.',
    'Bake for 2-4 minutes, or until the naan is puffed up and lightly golden brown. Keep a close eye on it as it can burn quickly at high temperatures.',
    'Brush with melted butter or oil and serve hot.',
    'Repeat with the remaining dough balls.',
  ],
  isGlutenFree: false,
  isVegan: false, // Contains yogurt and milk
  isVegetarian: true,
  isLactoseFree: false, // Contains yogurt and milk
),
Meal(
  id: 'm27',
  categories: [
    'c8', // Asian
  ],
  title: 'Soft and Fluffy Kulcha',
  affordability: Affordability.affordable,
  complexity: Complexity.challenging, // Achieving the soft, slightly chewy texture
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/e/e5/Kulchachole.jpg',
  duration: 100, // Includes dough rising time
  ingredients: [
    '2 cups All-purpose flour (maida)',
    '1 teaspoon Instant dry yeast',
    '1 teaspoon Sugar',
    '1/2 teaspoon Salt',
    '1/4 cup Yogurt',
    '1/4 cup Milk, lukewarm',
    '2-3 tablespoons Water, lukewarm (may vary)',
    '1 tablespoon Oil or melted butter, plus more for brushing',
    'Optional toppings: Butter, Cilantro, Onion seeds (kalonji)',
  ],
  steps: [
    'In a large bowl, whisk together the all-purpose flour, instant dry yeast, sugar, and salt.',
    'Add the yogurt, lukewarm milk, and oil or melted butter. Mix well.',
    'Gradually add lukewarm water, a little at a time, and mix until a soft, slightly sticky dough forms.',
    'Turn the dough out onto a lightly floured surface and knead for 8-10 minutes until it becomes smooth and elastic.',
    'Place the dough in a lightly oiled bowl, turning to coat. Cover the bowl with a damp cloth and let it rise in a warm place for at least 1-2 hours, or until doubled in size.',
    'Once the dough has risen, punch it down gently to release the air.',
    'Divide the dough into 6-8 equal-sized balls.',
    'Take one dough ball and gently roll it out into a slightly thick, oval or round shape (thicker than naan, about 1/2 inch).',
    'Optional: Brush the surface with water and sprinkle with chopped cilantro and onion seeds (kalonji). Gently press them down.',
    // Cooking on a Tawa (Griddle):
    'Heat a heavy flat griddle (tawa) over medium-high heat. Once hot, place the kulcha on the tawa (topped side up if you added toppings).',
    'Cook for 2-3 minutes until small bubbles appear on the surface and the bottom starts to get lightly browned.',
    'Flip the kulcha and cook for another 2-3 minutes until the other side is also lightly browned.',
    'You can gently press the edges with a clean cloth to help it puff up slightly.',
    'Brush generously with butter and serve hot.',
    // Cooking in an Oven (if no tandoor):
    'Preheat your oven to its highest setting (usually 230-250°C or 450-500°F) with a baking stone or inverted baking sheet inside.',
    'Place the rolled-out kulcha on the hot baking stone or sheet.',
    'Bake for 3-5 minutes, or until puffed up and lightly golden brown. Keep a close eye on it.',
    'Brush generously with butter and serve hot.',
    'Repeat with the remaining dough balls.',
  ],
  isGlutenFree: false,
  isVegan: false, // Contains yogurt and milk
  isVegetarian: true,
  isLactoseFree: false, // Contains yogurt and milk
),
Meal(
  id: 'm28',
  categories: [
    'c8', // Asian
    'c7', // Breakfast
  ],
  title: 'Classic Halwa Puri Breakfast',
  affordability: Affordability.affordable,
  complexity: Complexity.challenging, // Requires making multiple components
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/2/25/A_complete_meal.jpg',
  duration: 75, // Includes prep and cooking time for all components
  ingredients: [
    // For the Halwa (Semolina Pudding):
    '1 cup Semolina (suji)',
    '1 cup Sugar',
    '3 cups Water',
    '1/2 cup Ghee',
    '1/4 teaspoon Cardamom powder',
    'A few strands of Saffron (kesar) (optional)',
    'Chopped nuts (almonds, pistachios) for garnish',
    // For the Puri (Deep-fried Bread):
    '2 cups All-purpose flour (maida)',
    'A pinch of Salt',
    'Water, as needed',
    'Oil for deep frying',
    // For the Chana Masala (Chickpea Curry) - (We already have dummyChanaMasala, so we'll just reference it here in the steps for serving)
  ],
  steps: [
    // Making the Halwa:
    'Heat ghee in a pan. Add semolina and sauté on medium-low heat until it turns light golden brown and fragrant (about 8-10 minutes), stirring continuously to prevent burning.',
    'In a separate saucepan, combine water and sugar. Bring to a boil and cook until the sugar dissolves completely to form a syrup.',
    'Carefully pour the hot sugar syrup into the roasted semolina while stirring continuously. Be cautious as it may splutter.',
    'Add cardamom powder and saffron strands (if using). Cook on low heat, stirring constantly, until all the liquid is absorbed and the halwa thickens and leaves the sides of the pan.',
    'Garnish with chopped nuts and set aside.',
    // Making the Puri:
    'In a bowl, mix together all-purpose flour and salt.',
    'Gradually add water and knead to form a smooth, tight dough.',
    'Cover the dough with a damp cloth and let it rest for at least 20-30 minutes.',
    'Divide the dough into small, equal-sized balls.',
    'Roll out each dough ball into a small, thin circle (about 4-5 inches in diameter).',
    'Heat oil for deep frying in a wok or deep pan over medium-high heat. The oil should be hot enough for the puri to puff up immediately.',
    'Gently slide one rolled-out puri into the hot oil. Press it lightly with a slotted spoon to help it puff up.',
    'Fry until golden brown and crisp on both sides. Remove with a slotted spoon and drain on a paper towel.',
    'Repeat with the remaining dough balls.',
    // Serving Halwa Puri:
    'Serve the hot puris with the sweet halwa and a side of Chana Masala (refer to the steps in `dummyChanaMasala` for how to make it). You can also serve it with pickled vegetables (achar) for an extra zing.',
  ],
  isGlutenFree: false, // Puri is made with all-purpose flour
  isVegan: false, // Halwa often uses ghee
  isVegetarian: true,
  isLactoseFree: true, // If ghee is used in halwa and no dairy in chana masala
),
Meal(
  id: 'm29',
  categories: [
    'c8', // Asian
    'c7', // Breakfast or Brunch
  ],
  title: 'Spicy Chana Masala with Fluffy Puri',
  affordability: Affordability.affordable,
  complexity: Complexity.simple, // If you're familiar with making puris
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/e/ea/Chole_Bhature-Noida-UP-SP002.jpg',
  duration: 60, // Includes soaking time for chickpeas and frying puris
  ingredients: [
    // For the Puri (Deep-fried Bread):
    '2 cups All-purpose flour (maida)',
    'A pinch of Salt',
    'Water, as needed',
    'Oil for deep frying',
    // For the Chana Masala (Chickpea Curry) - (Using similar ingredients to dummyChanaMasala):
    '1 cup Dried chickpeas (chana)',
    '4 cups Water (for soaking)',
    '2 tablespoons Cooking oil',
    '1 large Onion, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '2 medium Tomatoes, finely chopped or pureed',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    '1/2 teaspoon Amchur powder (dried mango powder) or 1 tablespoon lemon juice',
    '1/4 teaspoon Asafoetida (hing) (optional)',
    '1-2 Green chilies, slit',
    'Fresh coriander leaves, chopped for garnish',
    'Salt to taste',
    '1 teaspoon Dried fenugreek leaves (kasuri methi), crushed (optional)',
    '1/2 teaspoon Baking soda (added while boiling chickpeas)',
  ],
  steps: [
    // Making the Puri:
    'In a bowl, mix together all-purpose flour and salt.',
    'Gradually add water and knead to form a smooth, tight dough.',
    'Cover the dough with a damp cloth and let it rest for at least 20-30 minutes.',
    'Divide the dough into small, equal-sized balls.',
    'Roll out each dough ball into a small, thin circle (about 4-5 inches in diameter).',
    'Heat oil for deep frying in a wok or deep pan over medium-high heat. The oil should be hot enough for the puri to puff up immediately.',
    'Gently slide one rolled-out puri into the hot oil. Press it lightly with a slotted spoon to help it puff up.',
    'Fry until golden brown and crisp on both sides. Remove with a slotted spoon and drain on a paper towel.',
    'Repeat with the remaining dough balls.',
    // Making the Chana Masala:
    'Soak the dried chickpeas in 4 cups of water overnight or for at least 6-8 hours.',
    'Drain the soaked chickpeas and rinse them well.',
    'In a pressure cooker or a pot, add the soaked chickpeas, fresh water (enough to cover them by about an inch), baking soda, and salt to taste. Pressure cook for 4-5 whistles or simmer in a pot until the chickpeas are very tender (about 45-60 minutes). Drain the chickpeas, reserving some of the cooking liquid.',
    'Heat oil in a pan or pot.',
    'Add asafoetida (hing), if using, and let it sizzle.',
    'Add the finely chopped onion and sauté until golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Add the finely chopped or pureed tomatoes and cook until they soften and the oil starts to separate.',
    'Stir in the red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a minute, stirring constantly.',
    'Add the boiled chickpeas and mix well with the masala. Add some of the reserved cooking liquid if the curry is too thick.',
    'Add garam masala, amchur powder (or lemon juice), slit green chilies, and salt to taste. Mix well.',
    'Crush the dried fenugreek leaves (kasuri methi) between your palms and add them to the curry (if using).',
    'Simmer for another 5-10 minutes to allow the flavors to meld.',
    'Garnish with fresh coriander leaves.',
    // Serving Chana Puri:
    'Serve the hot and fluffy puris with the flavorful and slightly tangy Chana Masala.',
  ],
  isGlutenFree: false, // Puri is made with all-purpose flour
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
// Meal(
//   id: 'm30',
//   categories: [
//     'c8', // Asian
//     'c7', // Breakfast or Brunch
//   ],
//   title: 'Delicious Anda Paratha (Egg Paratha)',
//   affordability: Affordability.affordable,
//   complexity: Complexity.simple,
//   imageUrl:
//       'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Anda_Paratha_at_a_dhaba.jpg/800px-Anda_Paratha_at_a_dhaba.jpg',
//   duration: 30,
//   ingredients: [
//     // For the Paratha Dough:
//     '2 cups Whole wheat flour (atta)',
//     'About 1/2 cup Water (may vary)',
//     '1/4 cup Ghee or oil, plus more for cooking',
//     'A pinch of salt (optional)',
//     // For the Egg Filling (per paratha):
//     '1-2 Eggs',
//     '1 small Onion, finely chopped',
//     '1-2 Green chilies, finely chopped (adjust to taste)',
//     'A pinch of Red chili powder (optional)',
//     'A pinch of Turmeric powder (optional)',
//     'A pinch of Garam masala (optional)',
//     'Fresh coriander leaves, chopped',
//     'Salt to taste',
//     'Oil or butter for cooking',
//   ],
//   steps: [
//     // Making the Paratha Dough:
//     'In a large bowl, add the whole wheat flour and salt (if using).',
//     'Gradually add water and knead to form a soft, smooth dough. It should not be sticky.',
//     'Knead the dough for 5-7 minutes until it becomes elastic.',
//     'Cover the dough with a damp cloth and let it rest for at least 15-20 minutes.',
//     // Preparing the Egg Filling:
//     'In a small bowl, whisk together the egg(s), finely chopped onion, finely chopped green chilies, red chili powder (if using), turmeric powder (if using), garam masala (if using), chopped coriander leaves, and salt to taste.',
//     // Assembling and Cooking the Anda Paratha:
//     'Divide the rested dough into small, equal-sized balls (about the size of a small lime).',
//     'Take one dough ball and roll it out into a small circle (about 4 inches in diameter).',
//     'Spread some ghee or oil over the rolled-out circle.',
//     'Fold the circle in half to form a semicircle. Spread some more ghee or oil on the semicircle.',
//     'Fold the semicircle in half again to form a triangle (or a spiral if you prefer).',
//     'Dust the triangular dough with some dry flour and gently roll it out again into a larger triangle (or circle), about 6-7 inches in diameter and not too thin.',
//     'Heat a flat griddle (tawa) over medium heat.',
//     'Place the rolled-out paratha on the hot tawa and cook for about 30 seconds to 1 minute on each side until it starts to look slightly cooked.',
//     'Pour some of the prepared egg mixture over the partially cooked paratha on the tawa, spreading it evenly but leaving a little space at the edges.',
//     'Carefully flip the paratha so that the egg side is now facing down on the tawa.',
//     'Drizzle some ghee or oil around the edges of the paratha.',
//     'Cook until the egg is fully cooked and the paratha is golden brown and crispy on both sides, pressing gently with a spatula.',
//     'Repeat the process with the remaining dough balls and egg mixture.',
//     'Serve hot with yogurt, pickles, or a side of tea.',
//   ],
//   isGlutenFree: false,
//   isVegan: false,
//   isVegetarian: false,
//   isLactoseFree: true, // If oil is used instead of ghee
// ),
Meal(
  id: 'm31',
  categories: [
    'c8', // Asian
    'c7', // Breakfast or Brunch
  ],
  title: 'Spicy Aloo Paratha (Potato Stuffed Bread)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/3/37/Aloo_Paratha_with_curd_and_Pickle.jpg',
  duration: 45,
  ingredients: [
    // For the Paratha Dough:
    '2 cups Whole wheat flour (atta)',
    'About 1/2 cup Water (may vary)',
    '1/4 cup Ghee or oil, plus more for cooking',
    'A pinch of salt (optional)',
    // For the Potato Filling:
    '2-3 medium Potatoes, boiled, peeled, and mashed',
    '1 small Onion, finely chopped',
    '1-2 Green chilies, finely chopped (adjust to taste)',
    '1/2 teaspoon Red chili powder (adjust to taste)',
    '1/4 teaspoon Turmeric powder',
    '1/2 teaspoon Coriander powder',
    '1/4 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    'Fresh coriander leaves, chopped',
    'Salt to taste',
    'A pinch of amchur powder (dried mango powder) or lemon juice (optional)',
  ],
  steps: [
    // Making the Paratha Dough:
    'In a large bowl, add the whole wheat flour and salt (if using).',
    'Gradually add water and knead to form a soft, smooth dough. It should not be sticky.',
    'Knead the dough for 5-7 minutes until it becomes elastic.',
    'Cover the dough with a damp cloth and let it rest for at least 15-20 minutes.',
    // Preparing the Potato Filling:
    'In a bowl, combine the mashed potatoes, finely chopped onion, finely chopped green chilies, red chili powder, turmeric powder, coriander powder, cumin powder, garam masala, chopped coriander leaves, salt to taste, and amchur powder or lemon juice (if using). Mix well until everything is evenly combined.',
    // Assembling and Cooking the Aloo Paratha:
    'Divide the rested dough into small, equal-sized balls (about the size of a small lime). Divide the potato filling into the same number of portions.',
    'Take one dough ball and roll it out into a small circle (about 3-4 inches in diameter).',
    'Place a portion of the potato filling in the center of the rolled-out dough.',
    'Bring the edges of the dough together and pinch them to seal the filling inside, forming a ball again.',
    'Gently flatten the stuffed dough ball and dust it with some dry whole wheat flour.',
    'Using a rolling pin, gently roll out the stuffed dough into a larger circle (about 6-7 inches in diameter). Be careful not to apply too much pressure, or the filling might come out.',
    'Heat a flat griddle (tawa) over medium heat.',
    'Place the rolled-out aloo paratha on the hot tawa and cook for about 1-2 minutes on each side until light brown spots start to appear.',
    'Drizzle some ghee or oil around the edges of the paratha.',
    'Flip the paratha and cook the other side until it turns golden brown and crispy, pressing gently with a spatula to ensure even cooking.',
    'Repeat the process with the remaining dough balls and filling.',
    'Serve hot with yogurt, butter, pickles, or a side of tea.',
  ],
  isGlutenFree: false,
  isVegan: true, // If oil is used instead of ghee
  isVegetarian: true,
  isLactoseFree: true, // If oil is used instead of ghee
),
// Meal(
//   id: 'm32',
//   categories: [
//     'c8', // Asian
//     'c7', // Breakfast (in some regions)
//   ],
//   title: 'Slow-Cooked Siri Paye (Head and Trotter Stew)',
//   affordability: Affordability.affordable,
//   complexity: Complexity.hard, // Requires long cooking time and specific preparation
//   imageUrl:
//       'https://upload.wikimedia.org/wikipedia/commons/thumb/a/a5/Siri_Paye.jpg/800px-Siri_Paye.jpg',
//   duration: 360, // This is an extremely slow-cooked dish!
//   ingredients: [
//     '1 Goat or Lamb head (siri), cleaned and cut into pieces (brain often cooked separately)',
//     '4 Goat or Lamb trotters (paye), cleaned and cut into pieces',
//     '2-3 large Onions, roughly chopped',
//     '2 tablespoons Ginger-garlic paste',
//     '1 teaspoon Red chili powder (adjust to taste)',
//     '1/2 teaspoon Turmeric powder',
//     '1 tablespoon Coriander powder',
//     '1/2 teaspoon Cumin powder',
//     '1/4 teaspoon Garam masala',
//     '2-3 Black cardamom pods',
//     '3-4 Green cardamom pods',
//     '4-5 Cloves',
//     '1-inch Cinnamon stick',
//     '2-3 Bay leaves',
//     'Salt to taste',
//     '6-8 cups Water or stock',
//     // Optional tempering (Tarka):
//     '2 tablespoons Oil or ghee',
//     '1 medium Onion, thinly sliced',
//     '1 teaspoon Kashmiri red chili powder (for color)',
//     'Fresh coriander leaves, chopped for garnish',
//     'Ginger, julienned for garnish',
//     'Lemon wedges for serving',
//   ],
//   steps: [
//     'Thoroughly clean the head and trotters under running water. The head might require special attention to remove any hair or impurities. The brain is often cooked separately due to its delicate nature.',
//     'In a large pot or pressure cooker, add the head pieces (excluding the brain initially), trotters, roughly chopped onions, ginger-garlic paste, red chili powder, turmeric powder, coriander powder, cumin powder, garam masala, black cardamom pods, green cardamom pods, cloves, cinnamon stick, bay leaves, and salt.',
//     'Add enough water or stock to cover the head and trotters generously (about 6-8 cups).',
//     'If using a pressure cooker, cook on high pressure for about 10-12 whistles, then reduce the heat and simmer for another 1-2 hours. If cooking in a regular pot, bring to a boil, then reduce the heat to the lowest setting, cover, and simmer for 6-8 hours, or even longer, until the meat is extremely tender and falling off the bones, and the broth is thick and gelatinous.',
//     'Once cooked, carefully remove the head and trotters from the pot. Strain the broth through a fine sieve to remove the whole spices and onion pieces. Return the meat to the strained broth.',
//     // Cooking the Brain (optional): The brain can be gently simmered separately in some of the broth or lightly sautéed with spices. It's very delicate and cooks quickly.
//     'For the optional tempering (tarka): Heat oil or ghee in a small pan. Add thinly sliced onions and fry until golden brown and crispy.',
//     'Remove the pan from the heat and stir in Kashmiri red chili powder for color.',
//     'Pour the tempering over the siri paye stew.',
//     'Garnish with fresh coriander leaves and julienned ginger.',
//     'Serve hot with naan and lemon wedges. The gelatinous broth and the tender meat are the highlights of this dish!',
//   ],
//   isGlutenFree: true, // If served without naan
//   isVegan: false,
//   isVegetarian: false,
//   isLactoseFree: true, // Traditionally no dairy, but be mindful of ghee used in tarka
//),
Meal(
  id: 'm33',
  categories: [
    'c8', // Asian
  ],
  title: 'Juicy Seekh Kebab',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging, // Getting the right texture and grilling
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/3/3a/Mutton_Seekh_Kabab.JPG',
  duration: 60, // Includes marination time
  ingredients: [
    '500g Minced meat (Beef, Lamb, or Chicken)',
    '1 medium Onion, finely chopped',
    '2-3 Green chilies, finely chopped (adjust to taste)',
    '1 tablespoon Ginger-garlic paste',
    '1 tablespoon Fresh coriander leaves, finely chopped',
    '1 tablespoon Fresh mint leaves, finely chopped',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    '1 tablespoon Lemon juice',
    '1 tablespoon Gram flour (besan) or breadcrumbs (optional, as a binder)',
    '2 tablespoons Yogurt (optional, for tenderizing)',
    'Salt to taste',
    'Oil for brushing',
  ],
  steps: [
    'In a large bowl, combine the minced meat, finely chopped onion, finely chopped green chilies, ginger-garlic paste, chopped coriander leaves, and chopped mint leaves.',
    'Add the red chili powder, turmeric powder, coriander powder, cumin powder, garam masala, lemon juice, and salt to taste.',
    'If using, add the gram flour (besan) or breadcrumbs and yogurt. Mix everything very well with your hands. Knead the mixture for a few minutes to ensure all the ingredients are thoroughly combined and the mixture is cohesive.',
    'Cover the bowl and refrigerate for at least 30 minutes to allow the flavors to meld.',
    'Wet your hands slightly to prevent the meat mixture from sticking.',
    'Take a portion of the meat mixture and shape it around a skewer (seekh). If you don\'t have skewers, you can shape them into small sausage-like shapes.',
    'Preheat your grill or barbecue to medium-high heat. You can also cook them in a preheated oven (broil setting) or on a hot pan.',
    'Brush the skewers lightly with oil.',
    'Grill, barbecue, bake, or pan-fry the seekh kebabs, turning them occasionally, until they are cooked through and nicely browned on all sides (about 15-20 minutes depending on the thickness and heat).',
    'Once cooked, carefully remove the kebabs from the skewers.',
    'Serve hot with naan, roti, or paratha, along with mint chutney, coriander chutney, or lemon wedges and sliced onions.',
  ],
  isGlutenFree: true, // If no binder is used
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true, // If no yogurt is used
),
Meal(
  id: 'm34',
  categories: [
    'c8', // Asian
    'c6', // Exotic (due to its unique flavor profile)
  ],
  title: 'Spicy Peshawari Chapli Kebab',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging, // Getting the texture and flavor balance right
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/9/96/Peshawari_Chapli_Kabab_by_Chef_Nina.jpg',
  duration: 50, // Includes marination time
  ingredients: [
    '500g Ground beef (preferably with some fat)',
    '1 medium Onion, finely chopped',
    '2-3 Green chilies, finely chopped (adjust to taste)',
    '1 tablespoon Ginger-garlic paste',
    '2 tablespoons Fresh coriander leaves, finely chopped',
    '1 tablespoon Fresh mint leaves, finely chopped',
    '1 tablespoon Anardana (dried pomegranate seeds), coarsely crushed',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    '1/2 teaspoon Crushed black peppercorns',
    '1 tablespoon Gram flour (besan) or cornstarch (as a binder)',
    '1 Egg (optional, as a binder)',
    'Salt to taste',
    'Oil for shallow frying',
    'Optional: Chopped tomatoes for topping',
  ],
  steps: [
    'In a large bowl, combine the ground beef, finely chopped onion, finely chopped green chilies, ginger-garlic paste, chopped coriander leaves, and chopped mint leaves.',
    'Add the coarsely crushed anardana, red chili powder, coriander powder, cumin powder, garam masala, crushed black peppercorns, and salt to taste.',
    'If using, add the gram flour (besan) or cornstarch and the egg. Mix everything very well with your hands. Knead the mixture for a few minutes to ensure all the ingredients are thoroughly combined.',
    'Cover the bowl and refrigerate for at least 30 minutes to allow the flavors to meld.',
    'Divide the meat mixture into equal-sized balls (about the size of a golf ball).',
    'Wet your hands slightly and flatten each ball into a round, slightly irregular-shaped patty, about 1/2 inch thick. Traditionally, they are not perfectly round.',
    'Heat oil for shallow frying in a large pan or skillet over medium heat.',
    'Carefully place the chapli kebabs in the hot oil, ensuring not to overcrowd the pan. You might need to fry them in batches.',
    'Cook for 5-7 minutes on each side, or until they are cooked through and nicely browned. If using, you can press a few chopped tomato pieces onto the top of the kebabs while they are frying.',
    'Once cooked, remove the chapli kebabs from the pan and drain them on a paper towel to remove excess oil.',
    'Serve hot with naan, roti, or on their own with a side of raita, chutney, and sliced onions.',
  ],
  isGlutenFree: true, // If cornstarch is used as a binder
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: true,
),

Meal(
  id: 'm35',
  categories: [
    'c8', // Asian
  ],
  title: 'Spicy and Smoky Chicken Tikka',
  affordability: Affordability.pricey,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/9/9d/Chicken-Tikka.jpg',
  duration: 150, // Includes marination time
  ingredients: [
    '500g Chicken pieces (boneless or with bone, thighs or breast)',
    '1 cup Yogurt',
    '2 tablespoons Ginger-garlic paste',
    '2 tablespoons Lemon juice',
    '1 tablespoon Red chili powder (adjust to taste)',
    '1 teaspoon Turmeric powder',
    '1 tablespoon Coriander powder',
    '1 teaspoon Cumin powder',
    '1/2 teaspoon Garam masala',
    '1 teaspoon Kasuri methi (dried fenugreek leaves), crushed',
    '1/2 teaspoon Ajwain (carom seeds) (optional)',
    'Food coloring, red or orange (optional)',
    'Salt to taste',
    'Oil or butter for brushing',
    'Chat masala for sprinkling (optional)',
    'Onion slices and lemon wedges for serving',
  ],
  steps: [
    'In a large bowl, combine the yogurt, ginger-garlic paste, lemon juice, red chili powder, turmeric powder, coriander powder, cumin powder, garam masala, crushed kasuri methi, ajwain (if using), food coloring (if using), and salt to taste. Mix well to form a smooth marinade.',
    'Add the chicken pieces to the marinade, ensuring they are well coated. Use your hands to rub the marinade into the chicken.',
    'Cover the bowl and refrigerate for at least 2 hours, or preferably overnight, to allow the flavors to penetrate deeply.',
    'Preheat your grill, barbecue, or oven to a high temperature (broil or grill setting). You can also use a tandoor if you have one.',
    'Thread the marinated chicken pieces onto skewers (if grilling or barbecuing) or arrange them in a single layer on a baking tray lined with foil (if baking).',
    'Brush the chicken pieces lightly with oil or butter.',
    'Grill, barbecue, or bake the chicken for about 15-20 minutes, turning them occasionally and brushing with more oil or butter, until they are cooked through and have a nice char.',
    'If baking, you can broil them for the last few minutes to get a smoky finish, keeping a close eye to prevent burning.',
    'Once cooked, remove the chicken tikka from the skewers or tray.',
    'Sprinkle with chat masala (if using) and serve hot with onion slices and lemon wedges. Mint chutney or coriander chutney also make great accompaniments.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: false,
),
Meal(
  id: 'm36',
  categories: [
    'c8', // Asian
  ],
  title: 'Creamy Malai Boti (Chicken with Cream)',
  affordability: Affordability.pricey,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/3/35/Chicken_Malai_Boti.JPG',
  duration: 180, // Includes longer marination time for tenderness
  ingredients: [
    '500g Boneless chicken cubes (breast or thigh)',
    '1 cup Yogurt, thick',
    '1/2 cup Fresh cream',
    '1 tablespoon Ginger-garlic paste',
    '1 tablespoon Lemon juice',
    '1 teaspoon Green chili paste (adjust to taste)',
    '1/2 teaspoon White pepper powder',
    '1/4 teaspoon Cardamom powder',
    'A pinch of Nutmeg powder',
    'Fresh coriander leaves, finely chopped',
    'Salt to taste',
    'Oil or butter for brushing',
  ],
  steps: [
    'In a large bowl, combine the thick yogurt, fresh cream, ginger-garlic paste, lemon juice, green chili paste, white pepper powder, cardamom powder, nutmeg powder, chopped coriander leaves, and salt to taste. Mix well to form a smooth and creamy marinade.',
    'Add the boneless chicken cubes to the marinade, ensuring they are fully coated. Use your hands to gently rub the marinade into the chicken.',
    'Cover the bowl and refrigerate for at least 3-4 hours, or preferably overnight, to allow the chicken to become very tender and absorb the flavors.',
    'Preheat your grill, barbecue, or oven to a medium-high temperature.',
    'Thread the marinated chicken cubes onto skewers (if grilling or barbecuing) or arrange them in a single layer on a baking tray lined with foil (if baking).',
    'Brush the chicken pieces lightly with oil or butter.',
    'Grill, barbecue, or bake the malai boti for about 15-20 minutes, turning them occasionally and brushing with more oil or butter, until they are cooked through and have a light golden hue.',
    'Ensure the chicken is cooked through and tender. You can check by inserting a knife into a piece; the juices should run clear.',
    'Once cooked, remove the malai boti from the skewers or tray.',
    'Serve hot with naan, roti, or on their own as an appetizer. A sprinkle of chaat masala and a side of mint chutney or coriander chutney complement it well.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: false, // Contains yogurt and cream
),
Meal(
  id: 'm37',
  categories: [
    'c8', // Asian
  ],
  title: 'Silky Reshmi Kebab',
  affordability: Affordability.pricey,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/5/5d/Chicken_reshmi_kebabs.jpg',
  duration: 180, // Includes longer marination time for the silky texture
  ingredients: [
    '500g Boneless chicken cubes (breast or thigh), preferably pounded slightly',
    '1/2 cup Yogurt, thick',
    '1/4 cup Fresh cream',
    '1 tablespoon Cashew paste (soaked cashews ground with a little milk)',
    '1 teaspoon Ginger-garlic paste',
    '1 teaspoon Green chili paste (adjust to taste)',
    '1/2 teaspoon White pepper powder',
    '1/4 teaspoon Cardamom powder',
    'A pinch of Mace powder (javitri) (optional)',
    'Fresh coriander leaves, finely chopped',
    'Salt to taste',
    'Oil or butter for brushing',
  ],
  steps: [
    'In a large bowl, combine the thick yogurt, fresh cream, cashew paste, ginger-garlic paste, green chili paste, white pepper powder, cardamom powder, mace powder (if using), chopped coriander leaves, and salt to taste. Mix well to form a smooth and rich marinade.',
    'Add the boneless chicken cubes (pounded slightly for extra tenderness) to the marinade, ensuring they are fully coated. Use your hands to gently rub the marinade into the chicken.',
    'Cover the bowl and refrigerate for at least 3-4 hours, or preferably overnight, to allow the chicken to become incredibly tender and absorb the subtle flavors.',
    'Preheat your grill, barbecue, or oven to a medium-high temperature.',
    'Thread the marinated chicken cubes onto skewers (if grilling or barbecuing) or arrange them in a single layer on a baking tray lined with foil (if baking).',
    'Brush the chicken pieces lightly with oil or butter.',
    'Grill, barbecue, or bake the reshmi kebab for about 12-15 minutes, turning them occasionally and brushing with more oil or butter, until they are cooked through and have a pale, creamy appearance with slight golden edges.',
    'Ensure the chicken is cooked through and exceptionally tender. The texture should be almost melt-in-your-mouth.',
    'Once cooked, remove the reshmi kebab from the skewers or tray.',
    'Serve hot with naan, roti, or on their own as a delicate appetizer. A squeeze of lemon and a side of mint chutney complement their mild flavor beautifully.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: false,
  isLactoseFree: false, // Contains yogurt and cream
),
// Meal(
//   id: 'm38',
//   categories: [
//     'c8', // Asian
//     'c5', // Light & Lovely
//   ],
//   title: 'Creamy Daal Mash (Split White Lentils)',
//   affordability: Affordability.affordable,
//   complexity: Complexity.simple,
//   imageUrl:
//       'https://upload.wikimedia.org/wikipedia/commons/thumb/d/d4/Maash_ki_Daal.jpg/800px-Maash_ki_Daal.jpg',
//   duration: 60, // Includes soaking time for lentils
//   ingredients: [
//     '1 cup Split white lentils (mash ki daal)',
//     '4 cups Water',
//     '1 medium Onion, finely chopped',
//     '1 tablespoon Ginger-garlic paste',
//     '2-3 Green chilies, slit',
//     '1/2 teaspoon Turmeric powder',
//     '1/2 teaspoon Red chili powder (optional)',
//     '1 teaspoon Coriander powder',
//     '1/2 teaspoon Cumin powder',
//     '1/4 teaspoon Garam masala',
//     '2 tablespoons Butter or ghee',
//     'Fresh coriander leaves, chopped for garnish',
//     'Fresh ginger, julienned for garnish',
//     'Salt to taste',
//     'Lemon juice (optional)',
//   ],
//   steps: [
//     'Wash the split white lentils thoroughly and soak them in water for at least 30 minutes.',
//     'Drain the soaked lentils and add them to a pot with 4 cups of fresh water, turmeric powder, red chili powder (if using), and salt. Bring to a boil, then reduce heat and simmer until the lentils are tender and slightly mushy (about 25-30 minutes). Skim off any foam that rises to the surface.',
//     'While the lentils are simmering, heat butter or ghee in a small pan.',
//     'Add the finely chopped onion and sauté until golden brown.',
//     'Add the ginger-garlic paste and sauté for a minute until fragrant.',
//     'Pour this tempering (tarka) into the cooked lentils. Add the slit green chilies, coriander powder, and cumin powder. Mix well and simmer for another 5-10 minutes.',
//     'Stir in the garam masala.',
//     'Garnish with fresh coriander leaves and julienned ginger.',
//     'Serve hot with roti, naan, or rice. A squeeze of lemon juice before serving is optional.',
//   ],
//   isGlutenFree: true,
//   isVegan: false, // If ghee is used
//   isVegetarian: true,
//   isLactoseFree: true, // If oil is used instead of ghee
// ),
Meal(
  id: 'm39',
  categories: [
    'c8', // Asian
    'c5' //light & lovely
  ],
  title: 'Smoky Baingan Bharta (Roasted Eggplant Mash)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/3/3a/Baingan_Ka_Bharta.JPG',
  duration: 60, // Includes roasting time for eggplant
  ingredients: [
    '2 large Eggplants (baingan)',
    '2 medium Onions, finely chopped',
    '2 medium Tomatoes, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '2-3 Green chilies, finely chopped (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    'Fresh coriander leaves, chopped for garnish',
    '2-3 tablespoons Cooking oil',
    'Salt to taste',
    'Lemon juice (optional)',
  ],
  steps: [
    'Roast the eggplants: You can roast them directly over an open flame on a gas stove, in a preheated oven (200°C or 400°F) until the skin is charred and the eggplant is soft (about 30-40 minutes), or on a grill.',
    'Once roasted, let the eggplants cool slightly. Peel off the charred skin and mash the pulp with a fork. Ensure there are no large chunks.',
    'Heat oil in a pan.',
    'Add the finely chopped onions and sauté until golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Stir in the finely chopped green chilies, turmeric powder, red chili powder, coriander powder, and cumin powder. Cook for a minute, stirring constantly.',
    'Add the finely chopped tomatoes and cook until they soften and the oil starts to separate from the masala.',
    'Add the mashed eggplant pulp and salt to taste. Mix well.',
    'Cover the pan and simmer on low heat for 10-15 minutes, stirring occasionally, to allow the flavors to meld.',
    'Stir in the garam masala and garnish generously with fresh coriander leaves.',
    'Serve hot with roti, naan, or paratha. A squeeze of lemon juice before serving is optional for added tang.',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm40',
  categories: [
    'c8', // Asian
    'c5', // Light & Lovely
  ],
  title: 'Simple and Nutritious Aloo Palak (Potatoes and Spinach)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/5/52/Rice%2C_Palak_Aloo%2C_Stir_Fried_Beans_%26_Potatoes%2C_A_Bowl_Of_Arhar_Dal.jpg',
  duration: 40,
  ingredients: [
    '2-3 medium Potatoes, peeled and cubed',
    '2 cups Fresh spinach (palak), washed and roughly chopped',
    '1 medium Onion, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '1-2 Green chilies, slit (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1/2 teaspoon Red chili powder (optional)',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    '2 tablespoons Cooking oil',
    'Salt to taste',
    'Lemon juice (optional)',
  ],
  steps: [
    'Heat oil in a pan.',
    'Add the finely chopped onions and sauté until light golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Stir in the turmeric powder, red chili powder (if using), coriander powder, and cumin powder. Cook for a few seconds, stirring constantly.',
    'Add the peeled and cubed potatoes and salt to taste. Mix well and cook, covered, on medium heat for about 10-15 minutes, or until the potatoes are almost tender, stirring occasionally to prevent sticking.',
    'Add the roughly chopped spinach and slit green chilies to the pan. Mix well with the potatoes and spices.',
    'Cover the pan again and cook on low heat until the spinach wilts and releases its moisture, and the potatoes are fully cooked and tender (about 5-7 minutes). There should be very little liquid left.',
    'Stir in the garam masala.',
    'Garnish with a squeeze of lemon juice (if using) before serving.',
    'Serve hot with roti or naan as a main dish, or as a side dish with other curries and rice.',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm41',
  categories: [
    'c8', // Asian
    'c5', // Light & Lovely
  ],
  title: 'Tangy and Spicy Bhindi Masala (Okra Stir-Fry)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/2/22/Bhindi_Masala.jpg',
  duration: 40,
  ingredients: [
    '500g Fresh okra (bhindi), washed and cut into 1-inch pieces',
    '2 medium Onions, thinly sliced',
    '2 medium Tomatoes, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '1-2 Green chilies, slit (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    '1 teaspoon Amchur powder (dried mango powder) or 1 tablespoon lemon juice',
    '2-3 tablespoons Cooking oil',
    'Salt to taste',
    'Fresh coriander leaves, chopped for garnish',
  ],
  steps: [
    'Wash the okra thoroughly and pat it completely dry. Cut off the ends and then cut the okra into 1-inch pieces.',
    'Heat oil in a pan.',
    'Add the thinly sliced onions and sauté until light golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Stir in the slit green chilies, turmeric powder, red chili powder, coriander powder, and cumin powder. Cook for a few seconds, stirring constantly.',
    'Add the cut okra and salt to taste. Mix well, ensuring the okra is coated with the spices.',
    'Cover the pan and cook on low to medium heat for about 15-20 minutes, or until the okra is tender but still slightly crisp. Stir occasionally to prevent sticking.',
    'Add the finely chopped tomatoes and amchur powder (or lemon juice). Mix well and cook uncovered for another 5-7 minutes, or until the tomatoes soften and the moisture has mostly evaporated.',
    'Stir in the garam masala and garnish with fresh coriander leaves.',
    'Serve hot with roti, naan, or as a side dish with rice and lentils.',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm42',
  categories: [
    'c8', // Asian
    'c6', // Exotic (due to its richness)
  ],
  title: 'Rich and Creamy Shahi Daal (Royal Lentils)',
  affordability: Affordability.pricey,
  complexity: Complexity.challenging, // Requires long simmering and rich ingredients
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/8/8a/DAL_MAKHANI.JPG', // Often similar to Dal Makhani
  duration: 120, // Includes soaking and long simmering time
  ingredients: [
    '1 cup Whole black lentils (urad sabut)',
    '1/4 cup Kidney beans (rajma)',
    '4 cups Water (for soaking)',
    '2 tablespoons Butter or ghee',
    '1 medium Onion, finely chopped',
    '1 tablespoon Ginger-garlic paste',
    '2 medium Tomatoes, pureed',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Garam masala',
    '1/2 cup Fresh cream',
    '1 tablespoon Kasuri methi (dried fenugreek leaves), crushed',
    'Salt to taste',
    'Fresh coriander leaves, chopped for garnish',
    'A pinch of sugar (optional, to balance flavors)',
  ],
  steps: [
    'Wash the whole black lentils and kidney beans thoroughly. Soak them together in 4 cups of water overnight or for at least 6-8 hours.',
    'Drain the soaked lentils and beans and add them to a pressure cooker with fresh water (about 4-5 cups) and salt. Pressure cook for 6-8 whistles or simmer in a pot until they are very soft and creamy (about 1-1.5 hours).',
    'Once cooked, mash some of the lentils and beans lightly with the back of a spoon to give the daal a creamy texture.',
    'Heat butter or ghee in a pan.',
    'Add the finely chopped onion and sauté until golden brown.',
    'Add the ginger-garlic paste and sauté for a minute until fragrant.',
    'Stir in the tomato puree and cook until the oil starts to separate from the masala.',
    'Add the red chili powder, turmeric powder, coriander powder, and cumin powder. Cook for a minute, stirring constantly.',
    'Pour the cooked lentils and beans into the pan with the tomato-onion mixture. Add more water if needed to achieve the desired consistency.',
    'Stir in the garam masala, crushed kasuri methi, and salt to taste. Add a pinch of sugar if using.',
    'Simmer on low heat for at least 30 minutes, stirring occasionally, to allow the flavors to meld together.',
    'Stir in the fresh cream just before serving.',
    'Garnish with fresh coriander leaves.',
    'Serve hot with naan, roti, or rice.',
  ],
  isGlutenFree: true, // If served with rice
  isVegan: false, // Contains butter/ghee and cream
  isVegetarian: true,
  isLactoseFree: false, // Contains cream
),
Meal(
  id: 'm43',
  categories: [
    'c8', // Asian
  ],
  title: 'Classic Aloo Samosa (Potato Samosa)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,// Requires making the filling and folding
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/3/3d/Samosa_Recipe_-_A_Mouth_Watering_Indian_Snack_Recipe_By_Sonia_Goyal_%2831078600701%29.jpg',
  duration: 60, // Includes prep and frying time
  ingredients: [
    // For the Dough:
    '2 cups All-purpose flour (maida)',
    '1/4 cup Oil or ghee',
    '1/2 teaspoon Ajwain (carom seeds) (optional)',
    'A pinch of Salt',
    'Water, as needed',
    // For the Potato Filling:
    '3-4 medium Potatoes, boiled, peeled, and mashed',
    '1 medium Onion, finely chopped',
    '1-2 Green chilies, finely chopped (adjust to taste)',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Red chili powder (adjust to taste)',
    '1/4 teaspoon Turmeric powder',
    '1/4 teaspoon Garam masala',
    '1/2 cup Green peas (matar), fresh or frozen',
    'Fresh coriander leaves, chopped',
    'Salt to taste',
    'Oil for deep frying',
  ],
  steps: [
    // Making the Dough:
    'In a large bowl, mix together the all-purpose flour, oil or ghee, ajwain (if using), and salt.',
    'Gradually add water, a little at a time, and knead to form a firm, non-sticky dough.',
    'Cover the dough with a damp cloth and let it rest for at least 20-30 minutes.',
    // Preparing the Potato Filling:
    'Heat a little oil in a pan. Add the finely chopped onion and sauté until light golden brown.',
    'Add the ginger-garlic paste (if using) and sauté for a minute.',
    'Stir in the green chilies, coriander powder, cumin powder, red chili powder, turmeric powder, and garam masala. Cook for a few seconds.',
    'Add the mashed potatoes and green peas. Mix well and cook for 2-3 minutes.',
    'Stir in the chopped coriander leaves and salt to taste. Let the filling cool completely.',
    // Assembling the Samosas:
    'Divide the rested dough into small, equal-sized balls.',
    'Take one dough ball and roll it out into an oval or circular shape (about 5-6 inches in diameter and not too thin).',
    'Cut the rolled-out dough in half.',
    'Take one half and apply a little water along the straight edge.',
    'Fold the straight edge to form a cone shape, overlapping the edges and pressing them together to seal.',
    'Fill the cone with a spoonful of the cooled potato filling.',
    'Apply a little water along the open edges of the cone and press them together to seal the samosa, ensuring there are no gaps.',
    'Repeat the process with the remaining dough and filling.',
    // Frying the Samosas:
    'Heat oil for deep frying in a wok or deep pan over medium heat. The oil should be hot but not smoking.',
    'Gently slide a few samosas into the hot oil (do not overcrowd the pan).',
    'Fry on medium heat until they turn golden brown and crisp on all sides, turning occasionally for even cooking (about 8-10 minutes per batch).',
    'Remove the fried samosas with a slotted spoon and drain them on a paper towel to remove excess oil.',
    'Serve hot with mint chutney, tamarind chutney, or ketchup. Enjoy with a cup of chai!',
  ],
  isGlutenFree: false,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm44',
  categories: [
    'c8', // Asian
  ],
  title: 'Crispy Mixed Vegetable Pakora',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/7/70/Taj_Mahal_-_Pakora.jpg',
  duration: 30, // Includes prep and frying time
  ingredients: [
    '1 cup Gram flour (besan)',
    '1/4 cup Rice flour (for extra crispiness, optional)',
    '1 teaspoon Red chili powder (adjust to taste)',
    '1/2 teaspoon Turmeric powder',
    '1 teaspoon Coriander powder',
    '1/2 teaspoon Cumin powder',
    '1/4 teaspoon Ajwain (carom seeds)',
    'A pinch of Baking soda (optional, for fluffiness)',
    'Salt to taste',
    'Water, as needed (to make the batter)',
    '1 medium Potato, thinly sliced',
    '1 medium Onion, thinly sliced',
    '1 cup Spinach leaves, roughly chopped',
    '1/2 cup Cauliflower florets, small',
    '1/2 cup Eggplant, thinly sliced (optional)',
    '2-3 Green chilies, finely chopped (adjust to taste)',
    'Fresh coriander leaves, chopped',
    'Oil for deep frying',
  ],
  steps: [
    'In a large bowl, whisk together the gram flour, rice flour (if using), red chili powder, turmeric powder, coriander powder, cumin powder, ajwain, baking soda (if using), and salt.',
    'Gradually add water, a little at a time, and mix well to form a smooth, medium-thick batter. The batter should be thick enough to coat the vegetables but not too runny.',
    'Add the sliced potatoes, sliced onions, chopped spinach, cauliflower florets, sliced eggplant (if using), chopped green chilies, and chopped coriander leaves to the batter. Mix gently until all the vegetables are well coated.',
    'Heat oil for deep frying in a wok or deep pan over medium-high heat. The oil should be hot but not smoking.',
    'Once the oil is hot, drop small spoonfuls of the vegetable and batter mixture into the oil. Do not overcrowd the pan.',
    'Fry the pakoras on medium heat until they turn golden brown and crisp on all sides, turning occasionally for even cooking (about 3-5 minutes per batch).',
    'Remove the fried pakoras with a slotted spoon and drain them on a paper towel to remove excess oil.',
    'Serve hot with mint chutney, tamarind chutney, raita, or ketchup. Enjoy with a hot cup of tea!',
  ],
  isGlutenFree: false, // Gram flour is not gluten-free
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm45',
  categories: [
    'c8', // Asian
    'c5', // Light & Lovely
  ],
  title: 'Cool and Tangy Dahi Bhalla',
  affordability: Affordability.affordable,
  complexity: Complexity.simple, // Requires making fritters and assembling
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/7/72/Dahi_bhalla_vada.jpg',
  duration: 90, // Includes soaking time for lentils and bhallas
  ingredients: [
    // For the Bhallas (Lentil Fritters):
    '1 cup Urad dal (split black lentils), skinless',
    '1/4 cup Moong dal (split yellow lentils)',
    'Water for soaking',
    '1/2 inch Ginger, finely chopped',
    '1-2 Green chilies, finely chopped (adjust to taste)',
    'A pinch of Asafoetida (hing) (optional)',
    'Salt to taste',
    'Oil for deep frying',
    // For the Dahi (Yogurt):
    '2 cups Plain yogurt (dahi), preferably slightly sweet',
    '2 tablespoons Sugar (adjust to taste)',
    // For the Sweet Chutney (Imli Chutney):
    'Tamarind pulp (imli), soaked and strained',
    'Sugar or jaggery to taste',
    'Ginger powder (sonth)',
    'Red chili powder (optional)',
    'Salt to taste',
    // For the Spicy Green Chutney (Hari Chutney):
    'Fresh mint leaves',
    'Fresh coriander leaves',
    'Green chilies',
    'Ginger',
    'Lemon juice',
    'Salt to taste',
    // For Garnishing:
    'Roasted cumin powder',
    'Red chili powder',
    'Chaat masala',
    'Sev (thin crispy noodles made from gram flour)',
    'Finely chopped onions (optional)',
    'Finely chopped coriander leaves',
  ],
  steps: [
    // Preparing the Bhallas:
    'Wash and soak the urad dal and moong dal together in enough water for at least 4-5 hours or overnight.',
    'Drain the soaked lentils and grind them in a blender or food processor with a little water to form a smooth, thick batter. It should be thick enough to hold its shape when dropped.',
    'Add finely chopped ginger, green chilies, asafoetida (if using), and salt to the batter. Mix well and whisk the batter for a few minutes to make it light and fluffy.',
    'Heat oil for deep frying in a wok or deep pan over medium heat.',
    'Drop small spoonfuls of the batter into the hot oil. Fry on medium heat until the bhallas are golden brown and cooked through. They should be soft and spongy.',
    'Remove the fried bhallas with a slotted spoon and soak them in lukewarm water for about 20-30 minutes to soften them further. Gently squeeze out the excess water from the soaked bhallas.',
    // Preparing the Yogurt:
    'Whisk the plain yogurt with sugar until smooth and slightly sweet. You can adjust the sweetness according to your preference.',
    // Assembling Dahi Bhalla:
    'Arrange the soaked and squeezed bhallas in a serving dish.',
    'Pour the sweetened yogurt generously over the bhallas, ensuring they are well coated.',
    'Drizzle sweet tamarind chutney and spicy green chutney over the yogurt.',
    'Sprinkle with roasted cumin powder, red chili powder, and chaat masala.',
    'Garnish with sev, finely chopped onions (if using), and finely chopped coriander leaves.',
    'Serve immediately or chill in the refrigerator for a while before serving. It tastes best when chilled.',
  ],
  isGlutenFree: true,
  isVegan: false, // Contains yogurt
  isVegetarian: true,
  isLactoseFree: false, // Contains yogurt
),
Meal(
  id: 'm46',
  categories: [
    'c8', // Asian
    'c5', // Light & Lovely
  ],
  title: 'Tangy and Spicy Papri Chaat',
  affordability: Affordability.affordable,
  complexity: Complexity.simple, // Requires multiple components
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/c/cd/Papri_Pakori_Chat.JPG',
  duration: 45, // Includes some prep time
  ingredients: [
    // For the Papri (Crispy Fried Discs):
    '1 cup All-purpose flour (maida)',
    '2 tablespoons Oil',
    'A pinch of Salt',
    'Water, as needed',
    'Oil for deep frying',
    // For the Base:
    '2 medium Potatoes, boiled, peeled, and diced',
    '1 cup Chickpeas (chana), boiled',
    '1 medium Onion, finely chopped',
    // For the Yogurt:
    '1 cup Plain yogurt (dahi), whisked and slightly sweetened',
    // For the Sweet Chutney (Imli Chutney): (Refer to Dahi Bhalla ingredients for details)
    // For the Spicy Green Chutney (Hari Chutney): (Refer to Dahi Bhalla ingredients for details)
    // For Garnishing:
    'Sev (thin crispy noodles made from gram flour)',
    'Chopped coriander leaves',
    'Roasted cumin powder',
    'Red chili powder',
    'Chaat masala',
  ],
  steps: [
    // Making the Papri:
    'In a bowl, mix together the all-purpose flour, oil, and salt.',
    'Gradually add water and knead to form a firm dough.',
    'Divide the dough into small balls and roll them out thinly into small discs.',
    'Deep fry the discs until they are golden brown and crispy. Set aside.',
    // Assembling the Chaat:
    'In a serving plate, arrange a layer of the crispy papris.',
    'Top with the diced boiled potatoes and boiled chickpeas.',
    'Sprinkle with finely chopped onions.',
    'Pour the whisked and sweetened yogurt generously over the mixture.',
    'Drizzle sweet tamarind chutney and spicy green chutney over the yogurt.',
    'Garnish generously with sev, chopped coriander leaves, roasted cumin powder, red chili powder, and chaat masala.',
    'Serve immediately to enjoy the crispy texture of the papri.',
  ],
  isGlutenFree: false, // Papri is made with all-purpose flour
  isVegan: false, // Contains yogurt
  isVegetarian: true,
  isLactoseFree: false, // Contains yogurt
),
Meal(
  id: 'm47',
  categories: [
    'c8', // Asian
    'c5', // Light & Lovely
  ],
  title: 'Tangy and Spicy Gol Gappa / Pani Puri',
  affordability: Affordability.affordable,
  complexity: Complexity.simple, // Requires making puris and the pani
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/2/22/Indian_cuisine-Panipuri-03.jpg',
  duration: 60, // Includes prep time
  ingredients: [
    // For the Puris (Gol Gappa/Papri):
    '1 cup Semolina (suji)',
    '1/4 cup All-purpose flour (maida)',
    'A pinch of Baking soda',
    'Water, as needed',
    'Oil for deep frying',
    // For the Pani (Spicy Water):
    '1 cup Fresh mint leaves',
    '1 cup Fresh coriander leaves',
    '2-3 Green chilies (adjust to taste)',
    '1 inch Ginger',
    '1 tablespoon Pani Puri masala (available in stores)',
    '1 teaspoon Roasted cumin powder',
    '1/2 teaspoon Black salt (kala namak)',
    '1/4 teaspoon Asafoetida (hing) (optional)',
    'Juice of 1-2 lemons or tamarind pulp to taste',
    'Sugar or jaggery to taste (optional)',
    '4-5 cups Water',
    'Ice cubes (optional, for serving chilled)',
    // For the Filling:
    '2 medium Potatoes, boiled, peeled, and mashed',
    '1 cup Chickpeas (chana), boiled',
    '1 small Onion, finely chopped (optional)',
    'Salt to taste',
    'Red chili powder (optional)',
  ],
  steps: [
    // Making the Puris (Gol Gappa/Papri):
    'In a bowl, mix together the semolina, all-purpose flour, and baking soda.',
    'Gradually add water and knead to form a stiff dough.',
    'Cover the dough and let it rest for at least 20 minutes.',
    'Divide the dough into small balls and roll them out thinly into small circles.',
    'Heat oil for deep frying in a wok or deep pan over medium-high heat.',
    'Fry the rolled-out puris until they puff up and turn golden brown and crispy. Drain on a paper towel and set aside.',
    // Making the Pani (Spicy Water):
    'In a blender, combine the mint leaves, coriander leaves, green chilies, and ginger with a little water. Blend to a smooth paste.',
    'In a large bowl, mix the blended paste with the remaining water.',
    'Add pani puri masala, roasted cumin powder, black salt, asafoetida (if using), lemon juice or tamarind pulp, and sugar or jaggery (if using). Mix well and adjust the seasonings to your taste. The pani should be tangy, spicy, and refreshing.',
    'Chill the pani in the refrigerator until serving.',
    // Preparing the Filling:
    'In a bowl, combine the mashed potatoes, boiled chickpeas, finely chopped onion (if using), salt, and red chili powder (if using). Mix well.',
    // Assembling and Serving Gol Gappa / Pani Puri:
    'To serve, make a small hole in the center of each crispy puri.',
    'Fill each puri with a spoonful of the potato and chickpea mixture.',
    'Dip the filled puri into the chilled pani until its full but not soggy, and eat it immediately to enjoy the burst of flavors!',
    'Serve the remaining puris, filling, and pani separately for everyone to assemble their own.',
  ],
  isGlutenFree: false, // Puris are typically made with semolina and all-purpose flour
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm48',
  categories: [
    'c8', // Asian
  ],
  title: 'Sweet and Crispy Jalebi',
  affordability: Affordability.affordable,
  complexity: Complexity.simple, // Requires getting the batter consistency and frying right
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/9/91/Jalebi-_Kolkata_-_West_Bengal_-_DSC_0011.jpg',
  duration: 75, // Includes fermentation time for the batter
  ingredients: [
    // For the Batter:
    '1 cup All-purpose flour (maida)',
    '2 tablespoons Gram flour (besan)',
    '1/4 teaspoon Baking soda',
    '1/4 teaspoon Turmeric powder or food coloring (orange/yellow)',
    '1/4 cup Yogurt, plain',
    'Water, as needed (for the batter)',
    'Ghee or oil for deep frying',
    // For the Sugar Syrup (Chashni):
    '1 cup Sugar',
    '1/2 cup Water',
    '1/4 teaspoon Cardamom powder',
    'A few strands of Saffron (kesar) (optional)',
    '1/2 teaspoon Lemon juice',
  ],
  steps: [
    // Preparing the Batter:
    'In a bowl, mix together the all-purpose flour, gram flour, baking soda, and turmeric powder or food coloring.',
    'Add the yogurt and gradually add water, mixing well to form a smooth, thick batter. The consistency should be such that it flows easily but is not too runny. It should be able to hold a shape when dropped.',
    'Cover the batter with a damp cloth and let it ferment in a warm place for at least 6-8 hours or overnight. The batter will rise slightly and have a slightly sour smell.',
    // Preparing the Sugar Syrup (Chashni):
    'In a saucepan, combine the sugar and water. Bring to a boil over medium heat and cook until the sugar dissolves completely and the syrup reaches a slightly sticky consistency (about 1-string consistency).',
    'Add cardamom powder, saffron strands (if using), and lemon juice. Stir well and keep the syrup warm.',
    // Frying the Jalebis:
    'Heat ghee or oil for deep frying in a flat-bottomed pan or wok over medium heat.',
    'Pour the fermented batter into a piping bag or a clean squeeze bottle with a small hole. Alternatively, you can use a clean cloth with a small hole.',
    'Squeeze the batter into the hot oil in a circular or pretzel-like spiral shape. Fry a few jalebis at a time, being careful not to overcrowd the pan.',
    'Fry the jalebis on medium heat until they are golden brown and crispy on both sides. Flip them gently as needed.',
    'Remove the fried jalebis from the oil with a slotted spoon and immediately immerse them in the warm sugar syrup for about 2-3 minutes, ensuring they are well soaked.',
    'Remove the soaked jalebis from the syrup and arrange them on a plate.',
    'Serve warm or at room temperature. Enjoy the sweet and crispy delight!',
  ],
  isGlutenFree: false,
  isVegan: false, // Contains yogurt
  isVegetarian: true,
  isLactoseFree: false, // Contains yogurt
),
Meal(
  id: 'm49',
  categories: [
    'c8', // Asian
  ],
  title: 'Creamy Rice Kheer (Rice Pudding)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/4/46/Kheer.jpg',
  duration: 60, // Includes simmering time
  ingredients: [
    '1/2 cup Basmati rice',
    '4 cups Full-fat milk',
    '1/2 cup Sugar (adjust to taste)',
    '1/2 teaspoon Cardamom powder',
    '2 tablespoons Chopped nuts (almonds, pistachios, cashews)',
    'A few strands of Saffron (kesar) (optional)',
    '1 teaspoon Rosewater (optional)',
  ],
  steps: [
    'Wash the basmati rice thoroughly and soak it in water for about 30 minutes.',
    'Drain the soaked rice and coarsely crush it with your hands or in a mortar and pestle. This helps in releasing starch and making the kheer creamier.',
    'In a heavy-bottomed pot or pan, bring the full-fat milk to a boil over medium heat. Stir occasionally to prevent it from sticking to the bottom.',
    'Once the milk boils, reduce the heat to low and add the crushed rice. Stir gently and continue to simmer on low heat, stirring frequently, for about 30-40 minutes, or until the rice is cooked and the kheer has thickened to your desired consistency.',
    'Add the sugar and cardamom powder. Stir well and continue to simmer for another 5-10 minutes, allowing the sugar to dissolve completely and the flavors to meld.',
    'If using saffron, soak the strands in a tablespoon of warm milk for a few minutes to extract the color and flavor, then add it to the kheer.',
    'Stir in the chopped nuts and rosewater (if using).',
    'Remove the kheer from the heat and let it cool slightly. It will thicken further as it cools.',
    'Serve warm or chilled, garnished with more chopped nuts.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: true,
  isLactoseFree: false,
),
Meal(
  id: 'm50',
  categories: [
    'c8', // Asian
  ],
  title: 'Rich and Festive Sheer Khurma (Vermicelli Pudding with Dates)',
  affordability: Affordability.pricey,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/b/bc/Sheer_khurma.jpg',
  duration: 45,
  ingredients: [
    '1/2 cup Fine vermicelli (seviyan)',
    '4 cups Full-fat milk',
    '1/2 cup Sugar (adjust to taste)',
    '1/2 cup Dates (khurma), pitted and chopped',
    '1/4 cup Chopped nuts (almonds, pistachios, cashews)',
    '2 tablespoons Raisins (kishmish)',
    '1/2 teaspoon Cardamom powder',
    'A few strands of Saffron (kesar) (optional)',
    '2 tablespoons Ghee',
  ],
  steps: [
    'Heat ghee in a heavy-bottomed pot or pan.',
    'Add the fine vermicelli and sauté on low heat until it turns light golden brown. Be careful not to burn it.',
    'Add the chopped nuts (reserving some for garnish) and raisins to the ghee and sauté for a minute until they are lightly roasted and fragrant.',
    'Pour in the full-fat milk and bring it to a boil over medium heat, stirring continuously to prevent sticking.',
    'Once the milk boils, reduce the heat to low and add the chopped dates and sugar. Stir well until the sugar dissolves.',
    'Add the cardamom powder and saffron strands (if using).',
    'Simmer on low heat for about 10-15 minutes, stirring occasionally, until the vermicelli is cooked and the sheer khurma has thickened slightly.',
    'Taste and adjust the sweetness if needed.',
    'Pour the sheer khurma into serving bowls.',
    'Garnish with the reserved chopped nuts.',
    'Serve warm or chilled. Its a must-have during Eid celebrations!',
  ],
  isGlutenFree: false, // Vermicelli is usually made from wheat
  isVegan: false,
  isVegetarian: true,
  isLactoseFree: false,
),
Meal(
  id: 'm51',
  categories: [
    'c8', // Asian
  ],
  title: 'Rich and Sweet Gajar ka Halwa (Carrot Pudding)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/4/42/Gajjar_ka_halwa_%28carrot_halwa%29.JPG',
  duration: 75, // Includes cooking time
  ingredients: [
    '1 kg Carrots, grated',
    '1 liter Full-fat milk',
    '1 cup Sugar (adjust to taste)',
    '1/2 cup Ghee',
    '1/2 teaspoon Cardamom powder',
    '1/4 cup Chopped nuts (almonds, pistachios, cashews)',
    '2 tablespoons Raisins (kishmish)',
    'A few strands of Saffron (kesar) (optional)',
  ],
  steps: [
    'Wash, peel, and grate the carrots.',
    'In a heavy-bottomed pot or pan, add the grated carrots and full-fat milk. Bring to a boil over medium heat, stirring occasionally.',
    'Once boiling, reduce the heat to low and let the carrots cook in the milk, stirring frequently, until all the milk has evaporated and the carrots are soft and mushy (this will take about 40-50 minutes).',
    'Add the sugar and ghee to the cooked carrots. Stir well and continue to cook on medium-low heat, stirring continuously, until the halwa starts to thicken and the ghee begins to separate from the mixture (about 10-15 minutes).',
    'Add the cardamom powder, chopped nuts, and raisins. Stir well.',
    'If using saffron, soak the strands in a tablespoon of warm milk for a few minutes and then add it to the halwa.',
    'Continue to cook for another 5-10 minutes, stirring constantly, until the halwa reaches your desired consistency and richness.',
    'Serve hot or warm, garnished with more chopped nuts. Its a perfect winter treat!',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: true,
  isLactoseFree: false,
),
Meal(
    id: 'm1',
    categories: [
      'c1',
      'c2',
    ],
    title: 'Spaghetti with Tomato Sauce',
    affordability: Affordability.affordable,
    complexity: Complexity.simple,
    imageUrl:
        'https://upload.wikimedia.org/wikipedia/commons/thumb/2/20/Spaghetti_Bolognese_mit_Parmesan_oder_Grana_Padano.jpg/800px-Spaghetti_Bolognese_mit_Parmesan_oder_Grana_Padano.jpg',
    duration: 20,
    ingredients: [
      '4 Tomatoes',
      '1 Tablespoon of Olive Oil',
      '1 Onion',
      '250g Spaghetti',
      'Spices',
      'Cheese (optional)'
    ],
    steps: [
      'Cut the tomatoes and the onion into small pieces.',
      'Boil some water - add salt to it once it boils.',
      'Put the spaghetti into the boiling water - they should be done in about 10 to 12 minutes.',
      'In the meantime, heaten up some olive oil and add the cut onion.',
      'After 2 minutes, add the tomato pieces, salt, pepper and your other spices.',
      'The sauce will be done once the spaghetti are.',
      'Feel free to add some cheese on top of the finished dish.'
    ],
    isGlutenFree: false,
    isVegan: true,
    isVegetarian: true,
    isLactoseFree: true,
  ),
  Meal(
    id: 'm2',
    categories: [
      'c2',
    ],
    title: 'Toast Hawaii',
    affordability: Affordability.affordable,
    complexity: Complexity.simple,
    imageUrl:
        'https://cdn.pixabay.com/photo/2018/07/11/21/51/toast-3532016_1280.jpg',
    duration: 10,
    ingredients: [
      '1 Slice White Bread',
      '1 Slice Ham',
      '1 Slice Pineapple',
      '1-2 Slices of Cheese',
      'Butter'
    ],
    steps: [
      'Butter one side of the white bread',
      'Layer ham, the pineapple and cheese on the white bread',
      'Bake the toast for round about 10 minutes in the oven at 200°C'
    ],
    isGlutenFree: false,
    isVegan: false,
    isVegetarian: false,
    isLactoseFree: false,
  ),
  Meal(
    id: 'm80',
    categories: [
      'c2',
      'c3',
    ],
    title: 'Classic Hamburger',
    affordability: Affordability.pricey,
    complexity: Complexity.simple,
    imageUrl:
        'https://cdn.pixabay.com/photo/2014/10/23/18/05/burger-500054_1280.jpg',
    duration: 45,
    ingredients: [
      '300g Cattle Hack',
      '1 Tomato',
      '1 Cucumber',
      '1 Onion',
      'Ketchup',
      '2 Burger Buns'
    ],
    steps: [
      'Form 2 patties',
      'Fry the patties for c. 4 minutes on each side',
      'Quickly fry the buns for c. 1 minute on each side',
      'Bruch buns with ketchup',
      'Serve burger with tomato, cucumber and onion'
    ],
    isGlutenFree: false,
    isVegan: false,
    isVegetarian: false,
    isLactoseFree: true,
  ),
  Meal(
    id: 'm81',
    categories: [
      'c4',
    ],
    title: 'Wiener Schnitzel',
    affordability: Affordability.luxurious,
    complexity: Complexity.challenging,
    imageUrl:
        'https://cdn.pixabay.com/photo/2018/03/31/19/29/schnitzel-3279045_1280.jpg',
    duration: 60,
    ingredients: [
      '8 Veal Cutlets',
      '4 Eggs',
      '200g Bread Crumbs',
      '100g Flour',
      '300ml Butter',
      '100g Vegetable Oil',
      'Salt',
      'Lemon Slices'
    ],
    steps: [
      'Tenderize the veal to about 2–4mm, and salt on both sides.',
      'On a flat plate, stir the eggs briefly with a fork.',
      'Lightly coat the cutlets in flour then dip into the egg, and finally, coat in breadcrumbs.',
      'Heat the butter and oil in a large pan (allow the fat to get very hot) and fry the schnitzels until golden brown on both sides.',
      'Make sure to toss the pan regularly so that the schnitzels are surrounded by oil and the crumbing becomes ‘fluffy’.',
      'Remove, and drain on kitchen paper. Fry the parsley in the remaining oil and drain.',
      'Place the schnitzels on awarmed plate and serve garnishedwith parsley and slices of lemon.'
    ],
    isGlutenFree: false,
    isVegan: false,
    isVegetarian: false,
    isLactoseFree: false,
  ),
  Meal(
    id: 'm82',
    categories: [
      'c2',
      'c5',
      'c10',
    ],
    title: 'Salad with Smoked Salmon',
    affordability: Affordability.luxurious,
    complexity: Complexity.simple,
    imageUrl:
        'https://cdn.pixabay.com/photo/2016/10/25/13/29/smoked-salmon-salad-1768890_1280.jpg',
    duration: 15,
    ingredients: [
      'Arugula',
      'Lamb\'s Lettuce',
      'Parsley',
      'Fennel',
      '200g Smoked Salmon',
      'Mustard',
      'Balsamic Vinegar',
      'Olive Oil',
      'Salt and Pepper'
    ],
    steps: [
      'Wash and cut salad and herbs',
      'Dice the salmon',
      'Process mustard, vinegar and olive oil into a dessing',
      'Prepare the salad',
      'Add salmon cubes and dressing'
    ],
    isGlutenFree: true,
    isVegan: false,
    isVegetarian: true,
    isLactoseFree: true,
  ),
  Meal(
    id: 'm83',
    categories: [
      'c6',
      'c10',
    ],
    title: 'Delicious Orange Mousse',
    affordability: Affordability.affordable,
    complexity: Complexity.hard,
    imageUrl:
        'https://cdn.pixabay.com/photo/2017/05/01/05/18/pastry-2274750_1280.jpg',
    duration: 240,
    ingredients: [
      '4 Sheets of Gelatine',
      '150ml Orange Juice',
      '80g Sugar',
      '300g Yoghurt',
      '200g Cream',
      'Orange Peel',
    ],
    steps: [
      'Dissolve gelatine in pot',
      'Add orange juice and sugar',
      'Take pot off the stove',
      'Add 2 tablespoons of yoghurt',
      'Stir gelatin under remaining yoghurt',
      'Cool everything down in the refrigerator',
      'Whip the cream and lift it under die orange mass',
      'Cool down again for at least 4 hours',
      'Serve with orange peel',
    ],
    isGlutenFree: true,
    isVegan: false,
    isVegetarian: true,
    isLactoseFree: false,
  ),
  Meal(
    id: 'm84',
    categories: [
      'c7',
    ],
    title: 'Pancakes',
    affordability: Affordability.affordable,
    complexity: Complexity.simple,
    imageUrl:
        'https://cdn.pixabay.com/photo/2018/07/10/21/23/pancake-3529653_1280.jpg',
    duration: 20,
    ingredients: [
      '1 1/2 Cups all-purpose Flour',
      '3 1/2 Teaspoons Baking Powder',
      '1 Teaspoon Salt',
      '1 Tablespoon White Sugar',
      '1 1/4 cups Milk',
      '1 Egg',
      '3 Tablespoons Butter, melted',
    ],
    steps: [
      'In a large bowl, sift together the flour, baking powder, salt and sugar.',
      'Make a well in the center and pour in the milk, egg and melted butter; mix until smooth.',
      'Heat a lightly oiled griddle or frying pan over medium high heat.',
      'Pour or scoop the batter onto the griddle, using approximately 1/4 cup for each pancake. Brown on both sides and serve hot.'
    ],
    isGlutenFree: true,
    isVegan: false,
    isVegetarian: true,
    isLactoseFree: false,
  ),
  Meal(
    id: 'm85',
    categories: [
      'c8',
    ],
    title: 'Creamy Indian Chicken Curry',
    affordability: Affordability.pricey,
    complexity: Complexity.challenging,
    imageUrl:
        'https://cdn.pixabay.com/photo/2018/06/18/16/05/indian-food-3482749_1280.jpg',
    duration: 35,
    ingredients: [
      '4 Chicken Breasts',
      '1 Onion',
      '2 Cloves of Garlic',
      '1 Piece of Ginger',
      '4 Tablespoons Almonds',
      '1 Teaspoon Cayenne Pepper',
      '500ml Coconut Milk',
    ],
    steps: [
      'Slice and fry the chicken breast',
      'Process onion, garlic and ginger into paste and sauté everything',
      'Add spices and stir fry',
      'Add chicken breast + 250ml of water and cook everything for 10 minutes',
      'Add coconut milk',
      'Serve with rice'
    ],
    isGlutenFree: true,
    isVegan: false,
    isVegetarian: false,
    isLactoseFree: true,
  ),
  Meal(
    id: 'm86',
    categories: [
      'c9',
    ],
    title: 'Chocolate Souffle',
    affordability: Affordability.affordable,
    complexity: Complexity.hard,
    imageUrl:
        'https://cdn.pixabay.com/photo/2014/08/07/21/07/souffle-412785_1280.jpg',
    duration: 45,
    ingredients: [
      '1 Teaspoon melted Butter',
      '2 Tablespoons white Sugar',
      '2 Ounces 70% dark Chocolate, broken into pieces',
      '1 Tablespoon Butter',
      '1 Tablespoon all-purpose Flour',
      '4 1/3 tablespoons cold Milk',
      '1 Pinch Salt',
      '1 Pinch Cayenne Pepper',
      '1 Large Egg Yolk',
      '2 Large Egg Whites',
      '1 Pinch Cream of Tartar',
      '1 Tablespoon white Sugar',
    ],
    steps: [
      'Preheat oven to 190°C. Line a rimmed baking sheet with parchment paper.',
      'Brush bottom and sides of 2 ramekins lightly with 1 teaspoon melted butter; cover bottom and sides right up to the rim.',
      'Add 1 tablespoon white sugar to ramekins. Rotate ramekins until sugar coats all surfaces.',
      'Place chocolate pieces in a metal mixing bowl.',
      'Place bowl over a pan of about 3 cups hot water over low heat.',
      'Melt 1 tablespoon butter in a skillet over medium heat. Sprinkle in flour. Whisk until flour is incorporated into butter and mixture thickens.',
      'Whisk in cold milk until mixture becomes smooth and thickens. Transfer mixture to bowl with melted chocolate.',
      'Add salt and cayenne pepper. Mix together thoroughly. Add egg yolk and mix to combine.',
      'Leave bowl above the hot (not simmering) water to keep chocolate warm while you whip the egg whites.',
      'Place 2 egg whites in a mixing bowl; add cream of tartar. Whisk until mixture begins to thicken and a drizzle from the whisk stays on the surface about 1 second before disappearing into the mix.',
      'Add 1/3 of sugar and whisk in. Whisk in a bit more sugar about 15 seconds.',
      'whisk in the rest of the sugar. Continue whisking until mixture is about as thick as shaving cream and holds soft peaks, 3 to 5 minutes.',
      'Transfer a little less than half of egg whites to chocolate.',
      'Mix until egg whites are thoroughly incorporated into the chocolate.',
      'Add the rest of the egg whites; gently fold into the chocolate with a spatula, lifting from the bottom and folding over.',
      'Stop mixing after the egg white disappears. Divide mixture between 2 prepared ramekins. Place ramekins on prepared baking sheet.',
      'Bake in preheated oven until scuffles are puffed and have risen above the top of the rims, 12 to 15 minutes.',
    ],
    isGlutenFree: true,
    isVegan: false,
    isVegetarian: true,
    isLactoseFree: false,
  ),
  Meal(
    id: 'm87',
    categories: [
      'c2',
      'c5',
      'c10',
    ],
    title: 'Asparagus Salad with Cherry Tomatoes',
    affordability: Affordability.luxurious,
    complexity: Complexity.simple,
    imageUrl:
        'https://cdn.pixabay.com/photo/2018/04/09/18/26/asparagus-3304997_1280.jpg',
    duration: 30,
    ingredients: [
      'White and Green Asparagus',
      '30g Pine Nuts',
      '300g Cherry Tomatoes',
      'Salad',
      'Salt, Pepper and Olive Oil'
    ],
    steps: [
      'Wash, peel and cut the asparagus',
      'Cook in salted water',
      'Salt and pepper the asparagus',
      'Roast the pine nuts',
      'Halve the tomatoes',
      'Mix with asparagus, salad and dressing',
      'Serve with Baguette'
    ],
    isGlutenFree: true,
    isVegan: true,
    isVegetarian: true,
    isLactoseFree: true,
  ),
  Meal(
  id: '88',
  categories: [
    'c7', // Breakfast (often enjoyed at breakfast)
  ],
  title: 'Doodh Patti Chai',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/b/b7/Chai_Latte_-_T_%40_The_Dials_2024-02-26.jpg',
  duration: 5, // Preparation time in minutes
  ingredients: [
    '2 cups Milk',
    '1 cup Water (optional, for a lighter chai)',
    '2 teaspoons Black tea leaves (Patti)',
    '2-3 teaspoons Sugar (to taste)',
  ],
  steps: [
    'Pour milk (and water, if using) into a saucepan and bring to a boil over medium heat.',
    'Once the milk starts to boil, add the black tea leaves.',
    'Let it simmer for 2-3 minutes, stirring occasionally, until the tea reaches a rich color.',
    'Add sugar to your desired sweetness and stir well.',
    'Strain the chai into cups and serve hot. Enjoy!',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: true,
  isLactoseFree: false,
),
Meal(
  id: 'm89',
  categories: [
    'c7', // Breakfast (often enjoyed at breakfast)
  ],
  title: 'Kashmiri Chai (Noon Chai)',
  affordability: Affordability.pricey, // Due to specific ingredients like Kashmiri tea leaves and nuts
  complexity: Complexity.challenging, // Requires a specific brewing process and ingredients
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/e/ed/Kashmiri_Chai.JPG',
  duration: 30, // Preparation time can be longer due to the slow simmering
  ingredients: [
    '4 cups Water',
    '2-3 Green Cardamom pods',
    '1-inch Cinnamon stick',
    '1/2 teaspoon Baking Soda', // Gives it the characteristic pink color
    '2 tablespoons Kashmiri Chai leaves (Green tea)',
    'Pinch of Salt', // Traditionally added for a savory note
    '4 cups Milk',
    '2-3 tablespoons Sugar (to taste, though some prefer it without)',
    'Pistachios, slivered (for garnish)',
    'Almonds, slivered (for garnish)',
  ],
  steps: [
    'In a large pot, bring water to a boil. Add cardamom pods, cinnamon stick, and baking soda. Simmer for 5 minutes.',
    'Add Kashmiri tea leaves and salt. Continue to simmer on low heat for 20-25 minutes, stirring occasionally. The tea should turn a deep reddish-brown color.',
    'Strain the tea to remove the leaves and spices. Discard the solids.',
    'In the same pot, add milk and sugar (if using). Bring to a gentle boil, stirring constantly to prevent scorching.',
    'Reduce heat and simmer for another 5 minutes, until the chai thickens slightly.',
    'Whisk the chai vigorously to create a frothy texture. This step is crucial for the authentic taste and appearance.',
    'Pour into cups and garnish with slivered pistachios and almonds. Serve hot.',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: true,
  isLactoseFree: false,
),

Meal(
  id: 'm90',
  categories: [
    'c7', // Breakfast, or enjoyed any time of day
  ],
  title: 'Adrak Wali Chai (Ginger Tea)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/f/f0/Kullad_chai.jpg', // Often looks similar to masala chai
  duration: 10, // Preparation time in minutes
  ingredients: [
    '2 cups Milk',
    '1 cup Water (optional, for a lighter chai)',
    '1 inch Ginger, grated or crushed',
    '2 teaspoons Black tea leaves (Patti)',
    '2-3 teaspoons Sugar (to taste)',
    '1-2 Green cardamom pods, crushed (optional)',
  ],
  steps: [
    'Pour milk (and water, if using) into a saucepan and bring to a boil over medium heat.',
    'Add the grated or crushed ginger. Let it simmer for a minute to infuse the milk with ginger flavor.',
    'Add the black tea leaves and crushed cardamom (if using).',
    'Continue to simmer for 2-3 minutes, stirring occasionally, until the tea reaches a nice color.',
    'Add sugar to your desired sweetness and stir well.',
    'Strain the chai into cups and serve hot. The warmth of ginger is wonderful!',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: true,
  isLactoseFree: false,
),
Meal(
  id: 'm91',
  categories: [
    'c7',
    'c5' // Often enjoyed after meals or as a welcoming drink
  ],
  title: 'Qahwa (Green Tea with Spices)',
  affordability: Affordability.affordable,
  complexity: Complexity.simple,
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/0/0d/Tulsi_Tea.JPG', // Often associated with a clear, light color
  duration: 10, // Preparation time in minutes
  ingredients: [
    '2 cups Water',
    '1 teaspoon Green tea leaves',
    '2-3 Green cardamom pods, lightly crushed',
    '1 small Cinnamon stick',
    'Sugar or Honey to taste (optional)',
    'Slivered almonds or pistachios (optional garnish)',
  ],
  steps: [
    'Pour water into a saucepan and bring it to a boil.',
    'Add the green tea leaves, crushed cardamom pods, and cinnamon stick.',
    'Reduce the heat and let it simmer gently for 2-3 minutes to allow the flavors to infuse.',
    'Strain the qahwa into cups.',
    'Add sugar or honey if desired and stir well.',
    'Garnish with a few slivered almonds or pistachios, if using.',
    'Serve hot and enjoy the refreshing and aromatic qahwa!',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true, // As it's traditionally made without milk
),

Meal(
  id: 'm92',
  categories: [
    'c7', // Breakfast or as a snack/drink
    'c5', // Light & Lovely (often perceived as a healthy option)
  ],
  title: 'Badam Milk (Almond Milk)',
  affordability: Affordability.pricey, // Almonds can be relatively expensive
  complexity: Complexity.simple, // Relatively easy to prepare
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/3/3c/BadamMilk.JPG',
  duration: 20, // Soaking time + preparation
  ingredients: [
    '1 cup Almonds, soaked overnight',
    '4 cups Milk (dairy or non-dairy like soy or oat, depending on preference)',
    '2-3 tablespoons Sugar or Honey (to taste)',
    '1/4 teaspoon Cardamom powder',
    'Few strands of Saffron (optional, for flavor and color)',
    'Pistachios, slivered (for garnish)',
    'Almonds, slivered (for garnish)',
  ],
  steps: [
    'Drain and peel the soaked almonds.',
    'In a blender, combine the peeled almonds with about 1 cup of milk. Blend until you get a smooth paste.',
    'Pour the almond paste into a saucepan along with the remaining milk.',
    'Add sugar or honey, cardamom powder, and saffron strands (if using).',
    'Heat the mixture on medium heat, stirring continuously, until it comes to a gentle simmer. Do not boil.',
    'Simmer for about 5-10 minutes to allow the flavors to meld and the milk to slightly thicken.',
    'Remove from heat and let it cool slightly.',
    'Strain the milk through a fine sieve or cheesecloth to remove any remaining almond pulp for a smoother texture (optional, some prefer it with the pulp).',
    'Serve warm or chilled, garnished with slivered pistachios and almonds.',
  ],
  isGlutenFree: true,
  isVegan: false, // Depends on the type of milk used
  isVegetarian: true,
  isLactoseFree: false, // Depends on the type of milk used
),
Meal(
  id: 'm94',
  categories: [
    'c7', // Breakfast (often enjoyed with breakfast)
    'c5', // Light & Lovely (can be refreshing, especially in summer)
  ],
  title: 'Lassi (Sweet)',
  affordability: Affordability.affordable, // Yogurt is generally affordable
  complexity: Complexity.simple, // Very easy to make
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/5/59/Lassi_1.jpg',
  duration: 5, // Preparation time is very quick
  ingredients: [
    '2 cups Plain Yogurt (Dahi)',
    '1 cup Cold Water or Milk (can adjust for desired consistency)',
    '2-4 tablespoons Sugar (to taste)',
    'Pinch of Cardamom powder (optional, for flavor)',
    'Ice cubes (optional)',
    'Fresh mint leaves (optional garnish)',
  ],
  steps: [
    'In a blender, combine the yogurt, cold water or milk, and sugar.',
    'Blend until smooth and frothy.',
    'Add cardamom powder if using and blend for a few more seconds.',
    'Pour into a tall glass.',
    'Add ice cubes if desired for a colder drink.',
    'Garnish with a sprig of fresh mint, if you like.',
    'Serve immediately and enjoy the refreshing sweetness!',
  ],
  isGlutenFree: true,
  isVegan: false,
  isVegetarian: true,
  isLactoseFree: false,
),
Meal(
  id: 'm93',
  categories: [
    'c5', // Light & Lovely (refreshing and hydrating)
    'c10', // Summer (a quintessential summer drink)
  ],
  title: 'Rooh Afza Sharbat',
  affordability: Affordability.affordable, // The syrup itself is reasonably priced and lasts a while
  complexity: Complexity.simple, // Very easy to prepare
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/0/0f/Rooh_Afza_%28Sharbat%29.JPG',
  duration: 2, // Preparation time is minimal
  ingredients: [
    '2-3 tablespoons Rooh Afza syrup (or to taste)',
    '1 glass (approx. 250ml) Cold Water or Milk (can be either, depending on preference)',
    'Ice cubes (optional)',
    'Lemon slice or mint leaves (optional garnish)',
  ],
  steps: [
    'Take a glass.',
    'Pour in the desired amount of Rooh Afza syrup.',
    'Add cold water or milk to the glass.',
    'Stir well until the syrup is fully mixed with the liquid.',
    'Add ice cubes if you prefer it chilled.',
    'Garnish with a slice of lemon or a few mint leaves, if desired.',
    'Serve immediately and enjoy the cooling and sweet refreshment!',
  ],
  isGlutenFree: true,
  isVegan: true, // If prepared with water
  isVegetarian: true,
  isLactoseFree: true, // If prepared with water
),
Meal(
  id: 'm95',
  categories: [
    'c5', // Light & Lovely (very refreshing and light)
    'c10', // Summer (an essential summer cooler)
  ],
  title: 'Nimbu Pani (Lemon Water)',
  affordability: Affordability.affordable, // Lemons and basic ingredients are usually inexpensive
  complexity: Complexity.simple, // Extremely easy to prepare
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/8/81/Nimbu_pani.JPG',
  duration: 5, // Preparation time is very quick
  ingredients: [
    '1-2 Lemons, juiced',
    '2 glasses (approx. 500ml) Cold Water',
    '2-4 teaspoons Sugar (or to taste)',
    'Pinch of Salt (optional, enhances flavor)',
    'Ice cubes',
    'Mint leaves or lemon slices (optional garnish)',
  ],
  steps: [
    'Squeeze the juice from the lemons into a jug or glasses.',
    'Add cold water and sugar (and salt, if using).',
    'Stir well until the sugar is completely dissolved.',
    'Add plenty of ice cubes.',
    'Garnish with mint leaves or lemon slices, if desired.',
    'Serve immediately and enjoy the tangy and refreshing Nimbu Pani!',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm96',
  categories: [
    'c5', // Light & Lovely (nutritious and can be light on the stomach)
    'c10', // Summer (a traditional summer cooler and energy drink)
  ],
  title: 'Sattu Drink',
  affordability: Affordability.affordable, // Sattu flour is generally inexpensive
  complexity: Complexity.simple, // Very easy to prepare
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/5/54/Sattu_Ghol.jpg',
  duration: 5, // Preparation time is minimal
  ingredients: [
    '2 tablespoons Sattu flour (ground roasted barley or gram)',
    '1 glass (approx. 250ml) Cold Water',
    '1-2 teaspoons Sugar or Jaggery (to taste)',
    'Pinch of Salt (optional, especially for savory versions)',
    'Lemon juice (optional, a few drops for tanginess)',
    'Roasted cumin powder (optional, a pinch for flavor)',
    'Fresh mint leaves (optional garnish)',
  ],
  steps: [
    'Take a glass and add the sattu flour.',
    'Gradually add cold water while stirring continuously to avoid lumps.',
    'Add sugar or jaggery (or salt if making a savory version) and stir well until dissolved.',
    'If desired, add a few drops of lemon juice and a pinch of roasted cumin powder.',
    'Mix well.',
    'Add ice cubes if you prefer it chilled.',
    'Garnish with a few fresh mint leaves, if you like.',
    'Serve immediately and enjoy this traditional and refreshing drink!',
  ],
  isGlutenFree: false, // Depends on the grain used (barley is not gluten-free, gram might be)
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm97',
  categories: [
    'c5', // Light & Lovely (refreshing and fruity)
    'c10', // Summer (a seasonal summer specialty)
  ],
  title: 'Falsa Juice',
  affordability: Affordability.affordable, // Falsa is usually reasonably priced when in season
  complexity: Complexity.simple, // Easy to make with a blender
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/9/9b/Crangeberry_Tea.jpg',
  duration: 10, // Includes washing and blending time
  ingredients: [
    '1 cup Fresh Falsa berries, washed',
    '2 cups Cold Water',
    '2-4 tablespoons Sugar (or to taste, falsa can be tart)',
    'Pinch of Black Salt (Kala Namak) (optional, adds a unique flavor)',
    'Ice cubes',
    'Mint leaves (optional garnish)',
  ],
  steps: [
    'Wash the falsa berries thoroughly.',
    'In a blender, combine the washed falsa berries and cold water.',
    'Blend until the berries are completely crushed and the mixture is smooth.',
    'Strain the juice through a fine sieve or muslin cloth to remove the seeds and skin. Use a spoon to press down on the pulp to extract as much juice as possible.',
    'Add sugar (and black salt, if using) to the strained juice and stir well until dissolved.',
    'Pour the juice into glasses filled with ice cubes.',
    'Garnish with a few fresh mint leaves, if desired.',
    'Serve immediately and enjoy the refreshing and slightly tangy falsa juice!',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm98',
  categories: [
    'c5', // Light & Lovely (naturally sweet and hydrating)
    'c10', // Summer (a quintessential summer drink)
  ],
  title: 'Sugarcane Juice (Ganne Ka Rass)',
  affordability: Affordability.affordable, // Sugarcane is usually reasonably priced
  complexity: Complexity.simple, // The process of extraction is simple, though requires a machine
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/f/f9/Glass_of_sugarcane_juice.jpg',
  duration: 5, // Time to extract and serve
  ingredients: [
    'Fresh Sugarcane stalks',
    'Ginger (optional, a small piece for added flavor)',
    'Mint leaves (optional, a few for freshness)',
    'Lemon juice (optional, a squeeze for tanginess)',
    'Ice cubes (usually served with)',
  ],
  steps: [
    'The sugarcane stalks are cleaned and fed through a sugarcane juice extraction machine.',
    'If desired, a small piece of ginger and a few mint leaves can be added along with the sugarcane to the machine for flavor infusion during extraction.',
    'The fresh juice is collected in a container.',
    'A squeeze of lemon juice can be added for a tangy twist.',
    'The juice is typically served immediately in a glass filled with ice cubes.',
    'Enjoy this naturally sweet and refreshing drink!',
  ],
  isGlutenFree: true,
  isVegan: true,
  isVegetarian: true,
  isLactoseFree: true,
),
Meal(
  id: 'm99',
  categories: [
    'c5', // Light & Lovely (refreshing and can be light)
    'c10', // Summer (a traditional summer cooler)
  ],
  title: 'Thandai',
  affordability: Affordability.pricey, // Due to the variety of nuts and spices
  complexity: Complexity.challenging, // Requires soaking and grinding of multiple ingredients
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/4/4e/Thandai_%28Spiced_Indian_Milk_Drink%29.JPG',
  duration: 60, // Soaking time is significant
  ingredients: [
    '1 tablespoon Almonds',
    '1 tablespoon Cashews',
    '1 tablespoon Pistachios',
    '1 tablespoon Melon seeds (Magaz)',
    '1 tablespoon Poppy seeds (Khaskhash)',
    '1 teaspoon Fennel seeds (Saunf)',
    '1/2 teaspoon Black peppercorns',
    '4-5 Green cardamom pods',
    'Few strands of Saffron',
    '1/2 cup Sugar (or to taste)',
    '2 cups Milk (full-fat preferred)',
    'Rose water (a few drops, optional)',
  ],
  steps: [
    'Soak almonds, cashews, pistachios, melon seeds, poppy seeds, fennel seeds, and black peppercorns in warm water overnight (or for at least 4-6 hours).',
    'In the morning, drain the soaked ingredients and peel the almonds (optional, but recommended for a smoother texture).',
    'Grind the soaked ingredients along with cardamom pods and saffron using a mortar and pestle or a blender with a little milk into a fine paste.',
    'In a separate bowl, mix the remaining milk with sugar until the sugar is dissolved.',
    'Strain the ground paste through a fine sieve or muslin cloth into the milk, pressing down to extract all the flavorful liquid. Discard the solids.',
    'Add a few drops of rose water, if using.',
    'Chill the thandai in the refrigerator for at least an hour before serving.',
    'Serve cold, garnished with slivered nuts (optional). Enjoy this cooling and aromatic drink!',
  ],
  isGlutenFree: true,
  isVegan: false, // Contains milk
  isVegetarian: true,
  isLactoseFree: false, // Contains milk
),
Meal(
  id: 'm100',
  categories: [
    'c5', // Light & Lovely (a sweet and fruity treat)
    'c10', // Summer (a quintessential summer indulgence)
  ],
  title: 'Mango Shake',
  affordability: Affordability.affordable, // Especially when mangoes are in season
  complexity: Complexity.simple, // Very easy to make in a blender
  imageUrl:
      'https://upload.wikimedia.org/wikipedia/commons/9/9b/Mango_Milk_Shake_%28Homemade%29.jpg',
  duration: 5, // Preparation time is minimal
  ingredients: [
    '2 ripe Mangoes, peeled and chopped',
    '1 cup Cold Milk (can be adjusted for desired thickness)',
    '1-2 tablespoons Sugar or Honey (to taste, depending on the sweetness of the mangoes)',
    'Few ice cubes (optional)',
    'Pistachios or almonds, slivered (optional garnish)',
  ],
  steps: [
    'Peel and chop the ripe mangoes, discarding the pit.',
    'In a blender, combine the chopped mango pieces and cold milk.',
    'Add sugar or honey according to your taste and the sweetness of the mangoes.',
    'Blend until smooth and creamy.',
    'Add a few ice cubes if you prefer a colder shake and blend briefly.',
    'Pour the mango shake into a glass.',
    'Garnish with slivered pistachios or almonds, if desired.',
    'Serve immediately and enjoy this delightful mango treat!',
  ],
  isGlutenFree: true,
  isVegan: false, // Contains milk
  isVegetarian: true,
  isLactoseFree: false, // Contains milk
),
];