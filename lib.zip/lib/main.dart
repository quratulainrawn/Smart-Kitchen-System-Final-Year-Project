import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:meals_config_fire/screens/categories.dart';
import 'package:meals_config_fire/screens/tabs.dart';
import 'package:meals_config_fire/screens/chat_screen.dart';
import 'package:firebase_core/firebase_core.dart';
import 'firebase_options.dart';
import 'package:meals_config_fire/screens/home_screen.dart';
import 'package:meals_config_fire/services/firebase_lisner.dart';
import 'package:meals_config_fire/services/alert_manager.dart';



final theme = ThemeData(
  useMaterial3: true,
  colorScheme: ColorScheme.fromSeed(
    brightness: Brightness.dark,
    seedColor: const Color.fromARGB(255, 131, 57, 0),
  ),
  textTheme: GoogleFonts.latoTextTheme(),
);

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(
    options: DefaultFirebaseOptions.currentPlatform,
);
FirebaseListener.startListening();
  runApp(const App());
}

class App extends StatelessWidget {
  const App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      theme: theme,
      //home: CategoriesScreen()
      home: Builder(
        builder: (context) {
          // Initialize AlertManager with context
          WidgetsBinding.instance.addPostFrameCallback((_) {
            AlertManager().setGlobalContext(context);
          });
          return const Tabs(); // Your tab navigation
        },
      ),
    );
    
  }
}



// import 'package:flutter/material.dart';
// import 'package:google_fonts/google_fonts.dart';
// import 'package:firebase_core/firebase_core.dart';
// import 'package:meals_config_fire/screens/home_screen.dart';
// import 'package:meals_config_fire/services/alert_manager.dart';
// import 'firebase_options.dart';
// import 'package:meals_config_fire/screens/tabs.dart';

// final theme = ThemeData(
//   useMaterial3: true,
//   colorScheme: ColorScheme.fromSeed(
//     brightness: Brightness.dark,
//     seedColor: const Color.fromARGB(255, 131, 57, 0),
//   ),
//   textTheme: GoogleFonts.latoTextTheme(),
//   appBarTheme: AppBarTheme(
//     centerTitle: true,
//     titleTextStyle: GoogleFonts.lato(
//       fontSize: 20,
//       fontWeight: FontWeight.bold,
//     ),
//   ),
// );

// void main() async {
//   WidgetsFlutterBinding.ensureInitialized();
//   await Firebase.initializeApp(
//     options: DefaultFirebaseOptions.currentPlatform,
//   );
//   runApp(const MyApp());
// }

// class MyApp extends StatefulWidget {
//   const MyApp({super.key});

//   @override
//   State<MyApp> createState() => _MyAppState();
// }

// class _MyAppState extends State<MyApp> {
//   // Global key for navigator to ensure alerts can be shown from anywhere
//   final GlobalKey<NavigatorState> navigatorKey = GlobalKey<NavigatorState>();

//   @override
//   void initState() {
//     super.initState();
//     // Initialize alert manager with navigator key
//     AlertManager().initialize(navigatorKey);
//   }

//   @override
//   Widget build(BuildContext context) {
//     return MaterialApp(
//       navigatorKey: navigatorKey,
//       debugShowCheckedModeBanner: false,
//       theme: theme,
//       home: Builder(
//         builder: (context) {
//           // Ensure context is available for alerts
//           WidgetsBinding.instance.addPostFrameCallback((_) {
//             AlertManager().setContext(context);
//           });
//           return const Tabs();
//         },
//       ),
//     );
//   }
// }