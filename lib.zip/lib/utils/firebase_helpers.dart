dynamic convertFirebaseData(dynamic data) {
  if (data is Map<dynamic, dynamic>) {
    return data.map<String, dynamic>((key, value) {
      return MapEntry(
        key.toString(),
        convertFirebaseData(value),
      );
    });
  } else if (data is List) {
    return data.map<dynamic>((e) => convertFirebaseData(e)).toList();
  }
  return data;
}