// services/firebase_listener.dart
import 'package:firebase_database/firebase_database.dart';
import 'package:meals_config_fire/models/smart_kitchen.dart';
import 'package:meals_config_fire/services/alert_manager.dart';
import '../utils/firebase_helpers.dart';
class FirebaseListener {
  static void startListening() {
    final ref = FirebaseDatabase.instance.ref('SmartKitchen');
    
    ref.onValue.listen((event) {
      if (event.snapshot.exists) {
        final data = convertFirebaseData(event.snapshot.value);
        if (data is Map<String, dynamic>) {
          final kitchenData = SmartKitchen.fromJson(data);
          AlertManager().handleCriticalAlerts(kitchenData);
        }
      }
    });
  }
}