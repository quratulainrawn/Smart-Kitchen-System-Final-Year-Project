import 'package:flutter/material.dart';
import 'package:meals_config_fire/models/smart_kitchen.dart';

class AlertManager {
  static final AlertManager _instance = AlertManager._internal();
  factory AlertManager() => _instance;
  AlertManager._internal();

  BuildContext? _globalContext;
  bool _showingAlert = false;

  void setGlobalContext(BuildContext context) {
    _globalContext = context;
  }

  void handleCriticalAlerts(SmartKitchen data) {
    final context = _globalContext;
    if (context == null || _showingAlert) return;

    // Gas leak - highest priority
    if (data.gasLevel > 3200) {
      _showGlobalAlert(
        context: context,
        title: "🚨 GAS LEAK DETECTED",
        message: "EVACUATE IMMEDIATELY!",
        color: Colors.red[900]!,
      );
    } 
    // Fire risk
    else if (data.temperature > 38.0) {
      _showGlobalAlert(
        context: context,
        title: "🔥 HIGH TEMPREATURE DETECTED",
        message: "Exhaust Fan Turned On!",
        color: const Color.fromARGB(255, 48, 174, 212)!,
      );
    }
  }

  void _showGlobalAlert({
    required BuildContext context,
    required String title,
    required String message,
    required Color color,
  }) {
    _showingAlert = true;
    
    showDialog(
      context: context,
      barrierDismissible: false, // Must acknowledge
      builder: (ctx) => AlertDialog(
        backgroundColor: color,
        title: Text(title, style: TextStyle(color: Colors.white)),
        content: Text(message, style: TextStyle(color: Colors.white)),
        actions: [
          TextButton(
            child: Text('OK', style: TextStyle(color: Colors.white)),
            onPressed: () {
              _showingAlert = false;
              Navigator.of(ctx).pop();
            },
          ),
        ],
      ),
    );
  }
}