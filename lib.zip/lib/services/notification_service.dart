// lib/services/notification_service.dart
import 'package:flutter/material.dart';
import 'package:meals_config_fire/models/smart_kitchen.dart';

class NotificationService {
  static final List<String> _shownNotificationIds = [];
  
  static void clearShownNotifications() {
    _shownNotificationIds.clear();
  }

  static void showRealTimeAlert({
    required BuildContext context,
    required String title,
    required String message,
    required Color color,
    required String notificationId, // Unique ID for each notification type
  }) {
    // Don't show if already shown
    if (_shownNotificationIds.contains(notificationId)) return;
    
    _shownNotificationIds.add(notificationId);
    
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        backgroundColor: color,
        content: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            Text(
              title,
              style: const TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
                color: Colors.white,
              ),
            ),
            Text(message),
          ],
        ),
        duration: const Duration(seconds: 5),
        behavior: SnackBarBehavior.floating,
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        action: SnackBarAction(
          label: 'Dismiss',
          textColor: Colors.white,
          onPressed: () {
            _shownNotificationIds.remove(notificationId);
            ScaffoldMessenger.of(context).hideCurrentSnackBar();
          },
        ),
      ),
    ).closed.then((reason) {
      _shownNotificationIds.remove(notificationId);
    });
  }

  static void handleRealTimeNotifications({
    required BuildContext context,
    required SmartKitchen? previousData,
    required SmartKitchen currentData,
  }) {
    // Handle initial state
    if (previousData == null) {
      _checkAllConditions(context, currentData);
      return;
    }

    // Baby Cry Notification
    if (currentData.babyCry != previousData.babyCry && currentData.babyCry) {
      showRealTimeAlert(
        context: context,
        title: "👶 Baby Alert!",
        message: currentData.notifications.babyCry,
        color: Colors.orange[800]!,
        notificationId: 'baby_cry',
      );
    }

    // Gas Leak Notification
    if (currentData.gasLevel > 3200 && previousData.gasLevel <= 3200) {
      showRealTimeAlert(
        context: context,
        title: "⚠ Gas Alert!",
        message: currentData.notifications.gas,
        color: Colors.red[800]!,
        notificationId: 'gas_leak',
      );
    }

    // High Temperature Notification
    if (currentData.temperature > 40.0 && previousData.temperature <= 40.0) {
      showRealTimeAlert(
        context: context,
        title: "🌡 Temperature Alert",
        message: currentData.notifications.temperature,
        color: Colors.blue[800]!,
        notificationId: 'high_temp',
      );
    }

    // Handle when conditions return to normal
    if (!currentData.babyCry && previousData.babyCry) {
      showRealTimeAlert(
        context: context,
        title: "👶 Baby Calm",
        message: "Baby is no longer crying",
        color: Colors.green[800]!,
        notificationId: 'baby_calm',
      );
    }
  }

  static void _checkAllConditions(BuildContext context, SmartKitchen data) {
    if (data.babyCry) {
      showRealTimeAlert(
        context: context,
        title: "👶 Baby Alert!",
        message: data.notifications.babyCry,
        color: Colors.orange[800]!,
        notificationId: 'baby_cry',
      );
    }
    if (data.gasLevel > 3200) {
      showRealTimeAlert(
        context: context,
        title: "⚠ Gas Alert!",
        message: data.notifications.gas,
        color: Colors.red[800]!,
        notificationId: 'gas_leak',
      );
    }
    if (data.temperature > 40.0) {
      showRealTimeAlert(
        context: context,
        title: "🌡 Temperature Alert",
        message: data.notifications.temperature,
        color: Colors.blue[800]!,
        notificationId: 'high_temp',
      );
    }
  }
}