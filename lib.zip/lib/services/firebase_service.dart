// lib/services/firebase_service.dart
import 'package:firebase_database/firebase_database.dart';
import 'package:meals_config_fire/models/smart_kitchen.dart';

Stream<SmartKitchen?> getSmartKitchenStream() {
  final ref = FirebaseDatabase.instance.ref('SmartKitchen');
  
  return ref.onValue.map((event) {
    if (event.snapshot.exists) {
      final rawData = Map<String, dynamic>.from(event.snapshot.value as Map);
      rawData['notifications'] = Map<String, dynamic>.from(rawData['notifications'] ?? {});
      return SmartKitchen.fromJson(rawData);
    }
    return null;
  });
}